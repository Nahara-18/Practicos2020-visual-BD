﻿Public Class Eje2
    Private Sub btnDefF_Click(sender As Object, e As EventArgs) Handles btnDefF.Click
        definicion.Text = Modulo1.defFuncion
    End Sub
End Class