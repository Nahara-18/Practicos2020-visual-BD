﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function conectar()
        co = New OdbcConnection("Dsn=prueba")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function

    Function login(ci, clave)
        Call conectar()
        cmd = New OdbcCommand("SELECT COUNT(*) FROM cliente  WHERE ci = '" & ci & "'  AND clave = '" & clave & "'", co)
        Return cmd.ExecuteScalar()
    End Function

    Sub listaProducto()
        Call conectar()
        ada = New OdbcDataAdapter("Select nombre AS NOMBRE, codigo AS CLAVE , precio AS PRECIO, disponible as Disponible ,fechaVencimiento as Vencimiento FROM producto ORDER BY fechaVencimiento ASC", co)
        ds = New DataSet()
        ada.Fill(ds)
        Form2.listProdug.DataSource = ds.Tables(0)
        Form2.listProdug.Columns("NOMBRE").Width = 100
        Form2.listProdug.Columns("CLAVE").Width = 100
        Form2.listProdug.Columns("PRECIO").Width = 100
        Form2.listProdug.Columns("Vencimiento").Width = 100
        Form2.listProdug.Columns("Disponible").Width = 100
    End Sub
End Module
