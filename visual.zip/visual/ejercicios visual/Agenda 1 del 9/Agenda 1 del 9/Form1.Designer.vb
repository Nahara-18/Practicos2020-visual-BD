﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dat = New System.Windows.Forms.TextBox()
        Me.m = New System.Windows.Forms.TextBox()
        Me.pacientes = New System.Windows.Forms.ComboBox()
        Me.odontologos = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dat
        '
        Me.dat.Location = New System.Drawing.Point(244, 43)
        Me.dat.Name = "dat"
        Me.dat.Size = New System.Drawing.Size(100, 20)
        Me.dat.TabIndex = 0
        '
        'm
        '
        Me.m.Location = New System.Drawing.Point(155, 193)
        Me.m.Multiline = True
        Me.m.Name = "m"
        Me.m.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.m.Size = New System.Drawing.Size(267, 117)
        Me.m.TabIndex = 1
        '
        'pacientes
        '
        Me.pacientes.FormattingEnabled = True
        Me.pacientes.Location = New System.Drawing.Point(239, 96)
        Me.pacientes.Name = "pacientes"
        Me.pacientes.Size = New System.Drawing.Size(121, 21)
        Me.pacientes.TabIndex = 2
        '
        'odontologos
        '
        Me.odontologos.FormattingEnabled = True
        Me.odontologos.Location = New System.Drawing.Point(239, 145)
        Me.odontologos.Name = "odontologos"
        Me.odontologos.Size = New System.Drawing.Size(121, 21)
        Me.odontologos.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(244, 337)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Guardar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(174, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Dia/Hora"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(174, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Paciente"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(174, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Odontologo"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(110, 193)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Motivo"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 416)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.odontologos)
        Me.Controls.Add(Me.pacientes)
        Me.Controls.Add(Me.m)
        Me.Controls.Add(Me.dat)
        Me.Name = "Form1"
        Me.Text = "Agenda"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dat As TextBox
    Friend WithEvents m As TextBox
    Friend WithEvents pacientes As ComboBox
    Friend WithEvents odontologos As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class
