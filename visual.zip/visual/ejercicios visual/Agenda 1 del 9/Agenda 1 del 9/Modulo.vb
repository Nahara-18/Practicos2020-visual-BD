﻿Imports System.Data.Odbc
Module Modulo
    Public cone As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function con()
        cone = New OdbcConnection("Dsn=conex")
        If cone.State = ConnectionState.Closed Then
            cone.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return cone
    End Function

    Sub rellenarP()
        Call con()
        ada = New OdbcDataAdapter("Select idpaciente,nompaciente from paciente", cone)
        ds = New DataSet()
        ada.Fill(ds)
        Form1.pacientes.DataSource = ds.Tables(0)
        Form1.pacientes.ValueMember = ds.Tables(0).Columns(0).Caption
        Form1.pacientes.DisplayMember = ds.Tables(0).Columns(1).Caption.ToString
    End Sub


    Sub Alta()
        Call con()
        Try
            cmd = New OdbcCommand("Insert into insumo(diahora, paciente, odontologo, motivoconsulta) values('" & Form1.dat.Text & "','" & Form1.pacientes.SelectedItem & "','" & Form1.odontologos.SelectedItem & "','" & Form1.m.Text & "')", cone)
            cmd.ExecuteNonQuery()

            MessageBox.Show("Agenda guardada", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'IngInsumo.nombre.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
End Module
