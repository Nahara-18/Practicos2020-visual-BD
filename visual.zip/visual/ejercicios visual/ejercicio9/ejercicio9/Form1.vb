﻿Public Class Ejercicio9
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim num, array(12), resto, paso As Integer
        array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}
        num = N.Text
        paso = 0

        tabla.Rows.Clear()
        While (paso < 13)
            resto = num * array(paso)
            tabla.Rows.Add(num, array(paso), resto)
            paso += 1
        End While

    End Sub

    Private Sub N_KeyPress(sender As Object, e As KeyPressEventArgs) Handles N.KeyPress

        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class
