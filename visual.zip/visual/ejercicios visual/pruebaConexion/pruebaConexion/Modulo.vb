﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function con()
        co = New OdbcConnection("Dsn=prueba1")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function

    Function login(usuario, clave)
        Call con()
        cmd = New OdbcCommand("SELECT COUNT(*) FROM login  WHERE usuNombre = '" & usuario & "'  AND usuClave = '" & clave & "'", co)
        Return cmd.ExecuteScalar()
    End Function

    Sub listar()
        Call con()
        ada = New OdbcDataAdapter("Select usuNombre AS NOMBRE, usuClave AS CLAVE , edad AS EDAD FROM login", co)
        ds = New DataSet()
        ada.Fill(ds)
        Form2.listadoUsuario.DataSource = ds.Tables(0)
        Form2.listadoUsuario.Columns("NOMBRE").Width = 100
        Form2.listadoUsuario.Columns("CLAVE").Width = 100
        Form2.listadoUsuario.Columns("EDAD").Width = 100
    End Sub

    Sub alta()
        Call con()
        If Form2.nomb.Text = "" Or Form2.clav.Text = "" Or Form2.eda.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                cmd = New OdbcCommand("Insert into login(usuNombre,usuClave,edad) values('" & Form2.nomb.Text & "'," & Form2.clav.Text & "," & Form2.eda.Text & ")", co)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Form2.nomb.Text = ""
                Form2.clav.Text = ""
                Form2.eda.Text = ""
                listar()

            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub

    Sub CargaDatos()
        'Call con()
        'cmd = New OdbcCommand("SELECT Nombre FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        'editarInsumo.Nombre.Text = cmd.ExecuteScalar()
    End Sub
    Sub rellenarComboBox()
        Call con()

        ada = New OdbcDataAdapter("Select idpaciente,nompaciente from paciente", cone)
        ds = New DataSet()
        ada.Fill(ds)
        'Form1.pacientes.DataSource = ds.Tables(0)
        'Form1.pacientes.ValueMember = ds.Tables(0).Columns(0).Caption
        'Form1.pacientes.DisplayMember = ds.Tables(0).Columns(1).Caption.ToString

    End Sub


End Module
