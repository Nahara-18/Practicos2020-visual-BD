﻿Module Modulo
    Public Function GenerarCadena(ByVal numeroCaracteres As Integer) As String

        ' Dimensionamos un array para almacenar tanto las
        ' letras mayúsculas como minúsculas (52 letras).
        '
        Dim letras(51) As String

        ' Rellenamos el array.
        '
        Dim n As Integer
        For item As Int64 = 65 To 90
            letras(n) = Chr(item)
            letras(n + 1) = letras(n).ToLower
            n += 2
        Next

        Dim cadenaAleatoria As String = String.Empty

        ' Iniciamos el generador de números aleatorios
        '
        Dim rnd As New Random(DateTime.Now.Millisecond)

        For n = 0 To numeroCaracteres

            Dim numero As Integer = rnd.Next(0, 51)

            cadenaAleatoria &= letras(numero)

        Next

        Return cadenaAleatoria

    End Function

    'Por ejemplo, si deseas que la cadena tenga 25 caracteres de longitud, llamarías a la función de la siguiente manera:

    ' TextBox1.Text = GenerarCadena(24)

    Function textoAleatorio()

        Dim obj As New Random()
        Dim posibles As String = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim longitud As Integer = posibles.Length
        Dim letra As Char
        Dim longitudnuevacadena As Integer = 5
        Dim nuevacadena As String = Nothing
        Dim numero As Integer = 0
        Do
            For i As Integer = 0 To longitudnuevacadena - 1
                letra = posibles(obj.[Next](longitud))
                ' If (letra.ToString * 1 > 47 And letra.ToString * 1 < 58) Then
                'numero += 2
                'End If
                nuevacadena += letra.ToString()
                i += 1
            Next

        Loop

        Return nuevacadena
    End Function
End Module
