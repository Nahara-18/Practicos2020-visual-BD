﻿Imports System.Data.Odbc
Module Modulo
    Public cone As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function con()
        cone = New OdbcConnection("Dsn=conex")
        If cone.State = ConnectionState.Closed Then
            cone.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return cone
    End Function

    Sub rellenarP()
        Call con()
        ada = New OdbcDataAdapter("Select idpaciente,nompaciente from paciente", cone)
        ds = New DataSet()
        ada.Fill(ds)
        Form1.pacientes.DataSource = ds.Tables(0)
        Form1.pacientes.ValueMember = ds.Tables(0).Columns(0).Caption
        Form1.pacientes.DisplayMember = ds.Tables(0).Columns(1).Caption.ToString
    End Sub

    Sub rellenarO()
        Call con()
        ada = New OdbcDataAdapter("Select idodontologo,nomodontologo from odontologo", cone)
        ds = New DataSet()
        ada.Fill(ds)
        Form1.odontologos.DataSource = ds.Tables(0)
        Form1.odontologos.ValueMember = ds.Tables(0).Columns(0).Caption
        Form1.odontologos.DisplayMember = ds.Tables(0).Columns(1).Caption.ToString
    End Sub

    Sub Alta()
        Call con()
        Dim t, Hora As String
        Hora = Form1.hora.Text & ":" & Form1.TextBox1.Text & ":00"
        t = Format(Form1.cale.SelectionEnd, "yyyy-MM-dd")
        Try
            cmd = New OdbcCommand("Insert into agenda(diahora, paciente, odontologo, motivoconsulta) values('" & t & " " & Hora & "'," & Form1.pacientes.SelectedIndex + 1 & "," & Form1.odontologos.SelectedIndex + 1 & ",'" & Form1.m.Text & "')", cone)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Agenda guardada", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'IngInsumo.nombre.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub

    Sub DatosAgenda()
        Call con()
        ada = New OdbcDataAdapter("Select diahora as Dia,paciente.nompaciente as Paciente,odontologo.nomodontologo as Odontologo, motivoconsulta as Motivo from agenda inner join paciente on idpaciente=paciente inner join odontologo on idodontologo=odontologo", cone)
        ds = New DataSet()
        ada.Fill(ds)
        Form2.listado.DataSource = ds.Tables(0)
        Form2.listado.Columns("Dia").Width = 100
        Form2.listado.Columns("Paciente").Width = 120
        Form2.listado.Columns("Odontologo").Width = 100
        Form2.listado.Columns("Motivo").Width = 200
    End Sub
End Module