﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Modulo.rellenarP()
        Modulo.rellenarO()

        pacientes.Text = "seleccione Paciente"
        odontologos.Text = "seleccione Odontologo"
    End Sub

    Private Sub dat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles hora.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub cale_DateChanged(sender As Object, e As DateRangeEventArgs) Handles cale.DateChanged
        dia.Text = cale.SelectionEnd.ToShortDateString
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Modulo.Alta()
    End Sub

    Private Sub dia_MouseMove(sender As Object, e As MouseEventArgs) Handles dia.MouseMove
        dia.Text = cale.SelectionEnd.ToShortDateString & " " & hora.Text & ":" & TextBox1.Text
    End Sub

    Private Sub Agenda_Click(sender As Object, e As EventArgs) Handles Agenda.Click
        Form2.Visible = True
    End Sub
End Class
