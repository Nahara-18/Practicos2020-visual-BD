﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.odontologos = New System.Windows.Forms.ComboBox()
        Me.pacientes = New System.Windows.Forms.ComboBox()
        Me.m = New System.Windows.Forms.TextBox()
        Me.hora = New System.Windows.Forms.TextBox()
        Me.dia = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.cale = New System.Windows.Forms.MonthCalendar()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Agenda = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(104, 333)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Motivo"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(146, 300)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "Odontologo"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(146, 273)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "Paciente"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(82, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Dia"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(199, 486)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Guardar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'odontologos
        '
        Me.odontologos.FormattingEnabled = True
        Me.odontologos.Location = New System.Drawing.Point(211, 297)
        Me.odontologos.Name = "odontologos"
        Me.odontologos.Size = New System.Drawing.Size(121, 21)
        Me.odontologos.TabIndex = 12
        '
        'pacientes
        '
        Me.pacientes.FormattingEnabled = True
        Me.pacientes.Location = New System.Drawing.Point(211, 270)
        Me.pacientes.Name = "pacientes"
        Me.pacientes.Size = New System.Drawing.Size(121, 21)
        Me.pacientes.TabIndex = 11
        '
        'm
        '
        Me.m.Location = New System.Drawing.Point(107, 349)
        Me.m.Multiline = True
        Me.m.Name = "m"
        Me.m.Size = New System.Drawing.Size(267, 117)
        Me.m.TabIndex = 10
        '
        'hora
        '
        Me.hora.Location = New System.Drawing.Point(230, 192)
        Me.hora.MaxLength = 2
        Me.hora.Name = "hora"
        Me.hora.Size = New System.Drawing.Size(19, 20)
        Me.hora.TabIndex = 9
        Me.hora.Text = "00"
        '
        'dia
        '
        Me.dia.AutoSize = True
        Me.dia.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dia.Location = New System.Drawing.Point(194, 224)
        Me.dia.Name = "dia"
        Me.dia.Size = New System.Drawing.Size(0, 18)
        Me.dia.TabIndex = 20
        Me.dia.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(235, 192)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(24, 18)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "   :"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(255, 192)
        Me.TextBox1.MaxLength = 2
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(19, 20)
        Me.TextBox1.TabIndex = 21
        Me.TextBox1.Text = "00"
        '
        'cale
        '
        Me.cale.Location = New System.Drawing.Point(117, 18)
        Me.cale.Name = "cale"
        Me.cale.TabIndex = 23
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(194, 194)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 13)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "Hora"
        '
        'Agenda
        '
        Me.Agenda.Location = New System.Drawing.Point(406, 20)
        Me.Agenda.Name = "Agenda"
        Me.Agenda.Size = New System.Drawing.Size(75, 23)
        Me.Agenda.TabIndex = 25
        Me.Agenda.Text = "Agenda"
        Me.Agenda.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(499, 521)
        Me.Controls.Add(Me.Agenda)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cale)
        Me.Controls.Add(Me.hora)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.dia)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.odontologos)
        Me.Controls.Add(Me.pacientes)
        Me.Controls.Add(Me.m)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Agenda"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents odontologos As ComboBox
    Friend WithEvents pacientes As ComboBox
    Friend WithEvents m As TextBox
    Friend WithEvents hora As TextBox
    Friend WithEvents dia As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents cale As MonthCalendar
    Friend WithEvents Label7 As Label
    Friend WithEvents Agenda As Button
End Class
