CREATE DATABASE clase0901;
USE clase0901;

CREATE TABLE paciente(
	idpaciente INT(4) PRIMARY KEY AUTO_INCREMENT,
	nompaciente VARCHAR(30) NOT NULL,
	telefono VARCHAR(30) NOT NULL
);

	INSERT INTO paciente(nompaciente, telefono) VALUES
	("Juan Pablo Segovia", "099526785"),
	("Ana Laura Fagundez", "091324499"),
	("Pedro Viera", "24506258"),
	("Esther Suarez", "27115978");

CREATE TABLE odontologo(
	idodontologo INT(4) PRIMARY KEY AUTO_INCREMENT,
	nomodontologo VARCHAR(30) NOT NULL
);

	INSERT INTO odontologo(nomodontologo) VALUES
	("Francisco Lopez"), ("Joaquin Mendez"), ("Ana Perez");

CREATE TABLE agenda(
	diahora DATETIME NOT NULL,
	paciente INT(4) NOT NULL,
	odontologo INT(4) NOT NULL,
	motivoconsulta VARCHAR(100) NOT NULL,
	PRIMARY KEY(diahora, odontologo),
	FOREIGN KEY(paciente) REFERENCES paciente(idpaciente),
	FOREIGN KEY(odontologo) REFERENCES odontologo(idodontologo)
);
