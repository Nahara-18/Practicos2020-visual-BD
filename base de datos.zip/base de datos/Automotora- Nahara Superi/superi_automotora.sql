-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-06-2020 a las 19:31:33
-- Versión del servidor: 5.7.14
-- Versión de PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `superi_automotora`
--
CREATE DATABASE IF NOT EXISTS `superi_automotora` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `superi_automotora`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alquila`
--

CREATE TABLE `alquila` (
  `fechaInicio` varchar(12) NOT NULL,
  `fechaFinalizacion` varchar(12) DEFAULT NULL,
  `ceduCliente` int(8) NOT NULL,
  `matrVehiculo` varchar(8) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alquila`
--

INSERT INTO `alquila` (`fechaInicio`, `fechaFinalizacion`, `ceduCliente`, `matrVehiculo`) VALUES
('6/10/2019', '15/06/2019', 12223334, 'SCP4579'),
('6/12/2020', '18/6/2020', 23335557, 'AAN2348'),
('4/9/2020', '17/4/2020', 34445556, 'MAB5655');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `cedula` int(8) NOT NULL,
  `cPNombre` varchar(15) NOT NULL,
  `cSNombre` varchar(15) DEFAULT NULL,
  `cPApellido` varchar(15) NOT NULL,
  `cSApellido` varchar(15) DEFAULT NULL,
  `calle` varchar(15) DEFAULT NULL,
  `numPuerta` varchar(20) DEFAULT NULL,
  `barrio` varchar(15) DEFAULT NULL,
  `numLibreta` varchar(25) DEFAULT NULL,
  `tarjetaCredito` varchar(25) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`cedula`, `cPNombre`, `cSNombre`, `cPApellido`, `cSApellido`, `calle`, `numPuerta`, `barrio`, `numLibreta`, `tarjetaCredito`) VALUES
(12223334, 'Alfredo', NULL, 'Silva', NULL, '18 de julio', '1070 apto 501', NULL, 'Cat A vence 20/11/2023', 'VISA vence 10/05/2021'),
(23335557, 'Josefina', NULL, 'Arendt', NULL, 'San Martin', '2052', NULL, 'Cat A vence 01/02/2022', 'AMEX vence 03/12/2022'),
(34445556, 'Carolina', NULL, 'Bermudez', NULL, 'Montero', '952', NULL, 'Cat A vence 15/10/2025', 'VESA vence 08/09/2020');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `documento` int(8) NOT NULL,
  `ePNombre` varchar(15) NOT NULL,
  `eSNombre` varchar(15) DEFAULT NULL,
  `ePApellido` varchar(15) NOT NULL,
  `eSApellido` varchar(15) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `cargo` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonocliente`
--

CREATE TABLE `telefonocliente` (
  `ceduCliente` int(8) NOT NULL,
  `telefono` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `telefonocliente`
--

INSERT INTO `telefonocliente` (`ceduCliente`, `telefono`) VALUES
(12223334, 99476018),
(23335557, 91963400),
(34445556, 95104875);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `telefonoempleado`
--

CREATE TABLE `telefonoempleado` (
  `documEmpleado` int(8) NOT NULL,
  `telefono` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculo`
--

CREATE TABLE `vehiculo` (
  `matricula` varchar(8) NOT NULL,
  `marca` varchar(10) NOT NULL,
  `modelo` varchar(10) NOT NULL,
  `anio` int(4) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `tipoCombustible` varchar(10) DEFAULT NULL,
  `cantPuertas` int(2) DEFAULT NULL,
  `tipo` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `vehiculo`
--

INSERT INTO `vehiculo` (`matricula`, `marca`, `modelo`, `anio`, `color`, `tipoCombustible`, `cantPuertas`, `tipo`) VALUES
('AAN2345', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2346', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2347', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2348', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2349', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2350', 'VW', 'UP', 2018, 'Blanco', NULL, 4, 'Auto'),
('AAN2351', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('AAN2352', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4578', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4579', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4580', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4581', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4583', 'VW', 'GOL', 2019, 'Gris', NULL, 4, 'Auto'),
('SCP4584', 'RENAULT', 'KWID', 2020, 'NEGRO', NULL, 4, 'Auto'),
('SCP4585', 'RENAULT', 'KWID', 2020, 'NEGRO', NULL, 4, 'Auto'),
('SCP4586', 'RENAULT', 'KWID', 2020, 'NEGRO', NULL, 4, 'Auto'),
('SCP4587', 'RENAULT', 'KWID', 2020, 'NEGRO', NULL, 4, 'Auto'),
('GBA1254', 'RENAULT', 'KWID', 2020, 'NEGRO', NULL, 4, 'Auto'),
('GBA1255', 'RENAULT', 'KWID', 2020, 'ROJO', NULL, 4, 'Auto'),
('MAB5648', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5649', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5650', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5651', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5652', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5653', 'VW', 'SAVEIRO', 2018, 'GRIS', NULL, 2, 'CAMIONETA'),
('MAB5654', 'VW', 'SAVEIRO', 2018, 'NEGRO', NULL, 4, 'CAMIONETA'),
('MAB5655', 'VW', 'SAVEIRO', 2018, 'NEGRO', NULL, 4, 'CAMIONETA'),
('MAB5656', 'VW', 'SAVEIRO', 2018, 'NEGRO', NULL, 4, 'CAMIONETA'),
('MAB5657', 'VW', 'SAVEIRO', 2018, 'NEGRO', NULL, 4, 'CAMIONETA'),
('SAB3485', 'GMC', '2XP', 2019, 'ROJO', NULL, 2, 'CAMION'),
('SAB3486', 'GMC', '2XP', 2019, 'ROJO', NULL, 2, 'CAMION'),
('SAB3487', 'GMC', '2XP', 2019, 'ROJO', NULL, 2, 'CAMION'),
('SAB3488', 'GMC', '2XP', 2019, 'ROJO', NULL, 2, 'CAMION');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alquila`
--
ALTER TABLE `alquila`
  ADD PRIMARY KEY (`ceduCliente`,`matrVehiculo`,`fechaInicio`),
  ADD KEY `fkA2` (`matrVehiculo`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`cedula`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`documento`);

--
-- Indices de la tabla `telefonocliente`
--
ALTER TABLE `telefonocliente`
  ADD PRIMARY KEY (`ceduCliente`,`telefono`);

--
-- Indices de la tabla `telefonoempleado`
--
ALTER TABLE `telefonoempleado`
  ADD PRIMARY KEY (`documEmpleado`,`telefono`);

--
-- Indices de la tabla `vehiculo`
--
ALTER TABLE `vehiculo`
  ADD PRIMARY KEY (`matricula`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
