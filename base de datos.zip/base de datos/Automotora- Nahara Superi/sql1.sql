CREATE database superi_automotora;
use superi_automotora;

CREATE table empleado(
documento int(8) PRIMARY KEY,
ePNombre varchar(15) NOT NULL,
eSNombre varchar(15),
ePApellido varchar(15) NOT NULL,
eSApellido varchar(15),
email varchar(40),
cargo varchar(15));

CREATE table vehiculo(
matricula varchar(8),
marca varchar(10) NOT NULL,
modelo varchar(10) NOT NULL,
anio int(4),
color varchar(10),
tipoCombustible varchar(10),
cantPuertas int(2),
tipo VARCHAR(10),
constraint PRIMARY KEY pkV(matricula));

CREATE table cliente(
cedula int(8) PRIMARY KEY,
cPNombre varchar(15) NOT NULL,
cSNombre varchar(15),
cPApellido varchar(15) NOT NULL,
cSApellido varchar(15),
calle varchar(15),
numPuerta varchar(20),
barrio varchar(15),
numLibreta varchar(25),
tarjetaCredito varchar(25));

CREATE table alquila(
fechaInicio varchar(12),
fechaFinalizacion varchar(12),
ceduCliente int(8),
matrVehiculo varchar(8),
constraint PRIMARY KEY pkA(ceduCliente,matrVehiculo, fechaInicio),
constraint FOREIGN KEY fkA1(ceduCliente) references cliente(cedula),
constraint FOREIGN KEY fkA2(matrVehiculo) references vehiculo(matricula));

CREATE table telefonoempleado(
documEmpleado int(8),
telefono int(15),
constraint PRIMARY KEY pkTE(documEmpleado, telefono),
constraint FOREIGN KEY fkTE(documEmpleado) references empleado(documento));

CREATE table telefonocliente(
ceduCliente int(8),
telefono int(15),
constraint PRIMARY KEY pkCE(ceduCliente, telefono),
constraint FOREIGN KEY fkCE(ceduCliente) references cliente(cedula));

INSERT into empleado(documento,ePNombre,ePApellido,cargo)
value(12345678,"Jorge","Fuentes","Mecanico"),
(21345678,"Marcus","Sarrus","Mecanico"),
(31245678,"Abc","Def","Mecanico");


INSERT into cliente(cedula,cPNombre,cPApellido,calle,numPuerta,numLibreta,tarjetaCredito)
values(12223334,"Alfredo","Silva","18 de julio","1070 apto 501","Cat A vence 20/11/2023","VISA vence 10/05/2021"),
(23335557,"Josefina","Arendt","San Martin",2052,"Cat A vence 01/02/2022","AMEX vence 03/12/2022"),
(34445556,"Carolina","Bermudez","Montero",952,"Cat A vence 15/10/2025","VESA vence 08/09/2020");

INSERT into telefonocliente(ceduCliente,telefono)
values(12223334,099476018),
(23335557,091963400),
(34445556,095104875);


INSERT into vehiculo(tipo,matricula,marca,modelo,anio,color,cantPuertas)
VALUES("Auto","AAN2345","VW","UP",2018,"Blanco",4),("Auto","AAN2346","VW","UP",2018,"Blanco",4),("Auto","AAN2347","VW","UP",2018,"Blanco",4),("Auto","AAN2348","VW","UP",2018,"Blanco",4),
("Auto","AAN2349","VW","UP",2018,"Blanco",4),("Auto","AAN2350","VW","UP",2018,"Blanco",4),("Auto","AAN2351","VW","GOL",2019,"Gris",4),("Auto","AAN2352","VW","GOL",2019,"Gris",4),
("Auto","SCP4578","VW","GOL",2019,"Gris",4),("Auto","SCP4579","VW","GOL",2019,"Gris",4),("Auto","SCP4580","VW","GOL",2019,"Gris",4),("Auto","SCP4581","VW","GOL",2019,"Gris",4),
("Auto","SCP4583","VW","GOL",2019,"Gris",4),("Auto","SCP4584","RENAULT","KWID",2020,"NEGRO",4),("Auto","SCP4585","RENAULT","KWID",2020,"NEGRO",4),("Auto","SCP4586","RENAULT","KWID",2020,"NEGRO",4),
("Auto","SCP4587","RENAULT","KWID",2020,"NEGRO",4),("Auto","GBA1254","RENAULT","KWID",2020,"NEGRO",4),("Auto","GBA1255","RENAULT","KWID",2020,"ROJO",4),
("CAMIONETA","MAB5648","VW","SAVEIRO",2018,"GRIS",2),("CAMIONETA","MAB5649","VW","SAVEIRO",2018,"GRIS",2),("CAMIONETA","MAB5650","VW","SAVEIRO",2018,"GRIS",2),
("CAMIONETA","MAB5651","VW","SAVEIRO",2018,"GRIS",2),("CAMIONETA","MAB5652","VW","SAVEIRO",2018,"GRIS",2),("CAMIONETA","MAB5653","VW","SAVEIRO",2018,"GRIS",2),
("CAMIONETA","MAB5654","VW","SAVEIRO",2018,"NEGRO",4),("CAMIONETA","MAB5655","VW","SAVEIRO",2018,"NEGRO",4),("CAMIONETA","MAB5656","VW","SAVEIRO",2018,"NEGRO",4),
("CAMIONETA","MAB5657","VW","SAVEIRO",2018,"NEGRO",4),("CAMION","SAB3485","GMC","2XP",2019,"ROJO",2),("CAMION","SAB3486","GMC","2XP",2019,"ROJO",2),("CAMION","SAB3487","GMC","2XP",2019,"ROJO",2),
("CAMION","SAB3488","GMC","2XP",2019,"ROJO",2),("CAMION","SAB3489","FORD","4",2020,"AMARILLO",2);



INSERT into alquila(ceduCliente,matrVehiculo,fechaInicio,fechaFinalizacion)
values(12223334,"SCP4579","6/10/2019","15/06/2019"),(23335557,"AAN2348","6/12/2020","18/6/2020"),(34445556,"MAB5655","4/9/2020","17/4/2020");


