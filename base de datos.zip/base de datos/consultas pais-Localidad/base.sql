Create database superi_consultas;
use superi_consultas;

CREATE table pais(
idPais int(3) primary key AUTO_INCREMENT,
nomPais varchar(25) NOT NULL,
poblacion int(11));

CREATE table localidad(
idLocalidad int(4) PRIMARY KEY AUTO_INCREMENT,
nomLocalidad varchar(25) not null,
fkPais int(3) NOT NULL,
foreign key(fkPais) references pais(idPais));

INSERT into pais(nomPais,poblacion)
values("Uruguay",3000000),("Argentina",30000000);

INSERT into localidad(nomLocalidad,fkPais)
values("Monevideo",1),("Mendoza",2),("San Jose",1),("Buenos Aires",2);