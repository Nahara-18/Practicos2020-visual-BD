﻿CREATE DATABASE impulso_tienda;
USE impulso_tienda;

CREATE TABLE fabricantes(
	clave INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(30)
);

CREATE TABLE articulos(
	clave_articulo INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(30),
	precio INT,
	clave_fabricante INT,
	FOREIGN KEY (clave_fabricante) REFERENCES fabricantes(clave_fabricante)
);

INSERT INTO fabricantes(nombre) 
VALUES("Kingston"),("Adata"),("Logitech"),("Lexar"),("Seagate");

INSERT INTO articulos(nombre, precio,clave_fabricante)
VALUES("Teclado",100,3),("Disco duro 300 GB",500,5),("Mouse",80,3),("Memoria USB",140,4),("Memoria RAM",290,1),("Disco duro extraíble 250GB",650,5),("Memoria USB",279,1),("DVD Rom",450,2),("CD Rom",200,2),("Tarjeta de red",180,3);

