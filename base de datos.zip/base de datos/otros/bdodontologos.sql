 CREATE DATABASE odondologos;
USE odondologos;

CREATE TABLE consultorios(
	numero INT(2) PRIMARY KEY AUTO_INCREMENT,
	ubicacion VARCHAR(20) NOT NULL
);

	INSERT INTO consultorios(ubicacion) VALUES
	("PLANTA BAJA"), ("PISO 1 FRENTE"), ("PISO 1 FONDO"), ("PISO 2 FRENTE"), ("PISO 2 FONDO"), ("PISO 3");

CREATE TABLE dentistas(
	ci INT(8) PRIMARY KEY,
	nombre VARCHAR(20) NOT NULL,
	apellido VARCHAR(20) NOT NULL,
	especialidad VARCHAR(30) NOT NULL,
	fecingreso DATE NOT NULL,
	observaciones VARCHAR(50)
);

	INSERT INTO dentistas VALUES
	(12223334, "Joaquin", "Leites", "Cirujano", "2017-02-15", "Atiende solo los jueves"),
	(23334445, "Patricia", "Fagundez", "Ortodoncia", "2017-02-01", "Agendar solo hasta las 15hrs"),
	(34445556, "Ana", "Perez", "Ortodoncia", "2019-07-20", NULL),
	(13334445, "Laura", "Segovia", "Ortodoncia", "2020-01-17", "Atiende a niños"),
	(25554449, "Francisco", "Marquez", "Cirujano", "2017-03-11", "Atiende lunes y viernes"),
	(43336665, "Julia", "Cubelo", "Cirujano", "2019-12-23", "Solo por la tarde");

CREATE TABLE teldentistas(
	ci INT(8),
	numero VARCHAR(10),
	PRIMARY KEY (ci, numero),
	FOREIGN KEY (ci) REFERENCES dentistas(ci)
);

	INSERT INTO teldentistas VALUES
	(43336665, "099552264"),
	(43336665, "091524872"),
	(34445556, "094538172"),
	(34445556, "099536170"),
	(34445556, "27102534"),
	(12223334, "24001125"),
	(12223334, "095671500"),
	(23334445, "098306090"),
	(13334445, "094101020"),
	(25554449, "099696563");

CREATE TABLE pacientes(
	ci INT(8) PRIMARY KEY,
	nombre1 VARCHAR(20) NOT NULL,
	nombre2 VARCHAR(20),
	apellido1 VARCHAR(20) NOT NULL,
	apellido2 VARCHAR(20),
	fecnacimiento DATE NOT NULL,
	email VARCHAR(25),
	observaciones VARCHAR(50)
);

	INSERT INTO pacientes VALUES
	(1234, "Joselo", NULL, "Bassat", "Rolon", "1980-01-25", NULL, NULL), 
	(2222, "Gabriela", "Maria", "Rolon", "Bolen", "1975-08-12", NULL, "Alergia a la anestesia"),
	(3214, "Brian", NULL, "Weiss", NULL, "1975-03-03", NULL, NULL),
	(6548, "Magali", NULL, "Torres", NULL, "1982-11-24", NULL, NULL);

CREATE TABLE telpacientes(
	ci INT(8),
	numero VARCHAR(10),
	PRIMARY KEY (ci, numero),
	FOREIGN KEY (ci) REFERENCES pacientes(ci)
);

	INSERT INTO telpacientes VALUES
	(1234, "091452264"),
	(1234, "099624872"),
	(2222, "099568172"),
	(3214, "099536170"),
	(3214, "27112356"),
	(6548, "24045278"),
	(6548, "091231500"),
	(6548, "099006090");

CREATE TABLE agenda(
	fecha DATE,
	hora TIME,
	consultorio INT(2),
	paciente INT(8) NOT NULL,
	dentista INT(8) NOT NULL,
	observaciones VARCHAR(50),
	PRIMARY KEY(fecha, hora, consultorio),
	FOREIGN KEY (paciente) REFERENCES pacientes(ci),
	FOREIGN KEY (dentista) REFERENCES dentistas(ci)
);

	INSERT INTO agenda VALUES
	("2018-05-16", "10:00:00", 2, 1234, 34445556, "Revision"),
	("2018-05-16", "10:30:00", 2, 6548, 34445556, "Control"),
	("2018-05-16", "11:00:00", 2, 3214, 34445556, "Control"),
	("2018-06-30", "14:00:00", 1, 1234, 23334445, "Control"),
	("2018-06-30", "14:15:00", 1, 6548, 23334445, NULL),
	("2018-06-30", "14:30:00", 1, 3214, 23334445, "Control"),
	("2018-07-16", "10:00:00", 2, 1234, 34445556, "Control"),
	("2018-07-16", "10:30:00", 2, 6548, 34445556, NULL),
	("2018-07-16", "11:00:00", 2, 3214, 34445556, "Control"),
	("2018-08-30", "13:00:00", 1, 1234, 23334445, "Control"),
	("2018-08-30", "13:15:00", 1, 6548, 23334445, "Control"),
	("2018-08-30", "13:30:00", 1, 3214, 23334445, "Control"),
	("2019-09-16", "09:30:00", 4, 1234, 12223334, "Muela de juicio"),
	("2019-09-16", "11:30:00", 4, 2222, 12223334, "Muela de juicio"),
	("2019-09-16", "13:30:00", 4, 6548, 12223334, "Muela de juicio");

CREATE TABLE consulta(
	idconsulta INT(10) PRIMARY KEY AUTO_INCREMENT,
	fecha DATETIME,
	paciente INT(8) NOT NULL,
	dentista INT(8) NOT NULL,
	detalle VARCHAR(150),
	FOREIGN KEY (paciente) REFERENCES pacientes(ci),
	FOREIGN KEY (dentista) REFERENCES dentistas(ci)
);

	INSERT INTO consulta (fecha, paciente, dentista, detalle) VALUES 
	("2018-05-16", 1234, 34445556, "Pase a ortodoncia"),
	("2018-05-16", 6548, 34445556, "Resortes adelante"),
	("2018-05-16", 3214, 34445556, "Ajuste"),
	("2018-06-30", 1234, 23334445, "Cambio de gomas"),
	("2018-06-30", 6548, 23334445, "Cambio de gomas"),
	("2018-06-30", 3214, 23334445, "Ajuste"),
	("2018-07-16", 1234, 34445556, "Ajuste"),
	("2018-07-16", 6548, 34445556, "Cambio de gomas"),
	("2018-07-16", 3214, 34445556, "Resortes adelante"),
	("2018-08-30", 1234, 23334445, "Aro superior"),
	("2018-08-30", 6548, 23334445, "Aro superior"),
	("2018-08-30", 3214, 23334445, "Cambio de gomas"),
	("2019-09-16", 1234, 12223334, "Extraccion superior"),
	("2019-09-16", 2222, 12223334, "Extraccion superior"),
	("2019-09-16", 6548, 12223334, "Extraccion inferior");
	
	Select apellido, especialidad, numero
	from dentistas
	inner join teldentistas
	on teldentistas.ci = dentistas.ci;