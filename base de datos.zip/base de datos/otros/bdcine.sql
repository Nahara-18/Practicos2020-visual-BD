CREATE DATABASE impulso_cine;
USE impulso_cine;

CREATE TABLE peliculas(
	pelicod INT(4) AUTO_INCREMENT PRIMARY KEY,
	pelinom VARCHAR(150) NOT NULL,
	pelical VARCHAR(200)
);

	INSERT INTO peliculas (pelinom, pelical)
	VALUES("Moana","Apta todo publico"),
	("Iron Man","Apta todo publico"),
	("Los vengadores","Apta todo publico"),
	("50 sombras","Apta +18"),
	("Bailarina","Apta todo publico"),
	("La llamada","Apta +18"),
	("La la land","Apta +13"),
	("Los pitufos","Apta todo publico"),
	("Un camino a casa","Apta todo publico"),
	("Nieve negra","Apta +15"),
	("Belleza inesperada","Apta +15"),
	("Hasta el último hombre","Apta +13"),
	("Terminator", NULL),
	("La bella y la bestia", NULL),
	("Minions", NULL);

CREATE TABLE salas(
	salcod INT(2) AUTO_INCREMENT PRIMARY KEY,
	salnom VARCHAR(25) NOT NULL
);

	INSERT INTO salas(salnom)
	VALUES("Sala UNO"),("Sala DOS"),("Sala TRES"),("Sala GRANDE"),("Sala AL FONDO");

CREATE TABLE programacion(
	progfechahora DATETIME NOT NULL,
	pelicula INT(4) NOT NULL,
	sala INT(2) NOT NULL,
	PRIMARY KEY (progfechahora, pelicula, sala),
	FOREIGN KEY(pelicula) REFERENCES peliculas(pelicod),
	FOREIGN KEY(sala) REFERENCES salas(salcod)
);
	
	INSERT INTO programacion VALUES
	("2019-12-12 20:00:00", 3, 2),
	("2019-12-12 22:30:00", 3, 2),
	("2019-12-13 20:00:00", 3, 4),
	("2019-12-13 22:30:00", 3, 4),
	("2019-12-14 14:00:00", 1, 2),
	("2019-12-14 16:30:00", 1, 2),
	("2019-12-14 14:00:00", 5, 3),
	("2019-12-14 16:30:00", 5, 3),
	("2019-12-20 14:00:00", 6, 1),
	("2019-12-20 16:30:00", 14, 1),
	("2019-12-27 14:00:00", 14, 1),
	("2019-12-27 16:30:00", 15, 2),
	("2019-12-27 16:30:00", 15, 4),
	("2019-12-27 14:00:00", 8, 1),
	("2020-01-05 20:00:00", 2, 4),
	("2020-01-05 22:30:00", 4, 4),
	("2020-02-01 20:00:00", 3, 2),
	("2020-02-01 22:30:00", 3, 2),
	("2020-02-02 20:00:00", 3, 4),
	("2020-02-02 22:30:00", 3, 4),
	("2020-02-03 14:00:00", 1, 2),
	("2020-02-03 16:30:00", 1, 2),
	("2020-02-03 14:00:00", 5, 3),
	("2020-02-03 16:30:00", 5, 3),
	("2020-02-10 14:00:00", 6, 1),
	("2020-02-10 16:30:00", 14, 1),
	("2020-02-15 14:00:00", 14, 1),
	("2020-02-15 16:30:00", 15, 2),
	("2020-02-15 16:30:00", 15, 4),
	("2020-02-15 14:00:00", 8, 1);

