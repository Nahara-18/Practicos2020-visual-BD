-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-06-2020 a las 21:08:24
-- Versión del servidor: 5.7.14
-- Versión de PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `superi_personal`
--
CREATE DATABASE IF NOT EXISTS `superi_personal` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `superi_personal`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `clave` int(10) NOT NULL,
  `nombre` varchar(15) DEFAULT NULL,
  `presupuesto` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`clave`, `nombre`, `presupuesto`) VALUES
(1, 'Almacen', 70000),
(2, 'Contabilidad', 60000),
(3, 'Manufactura', 50000),
(4, 'Empaque', 30000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `clave` varchar(10) NOT NULL,
  `nombre` varchar(15) DEFAULT NULL,
  `apellido` varchar(15) DEFAULT NULL,
  `clavDep` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`clave`, `nombre`, `apellido`, `clavDep`) VALUES
('EMP01', 'Tatiana', 'Vargas', 1),
('EMP02', 'Laura', 'Perez', 2),
('EMP03', 'Armando', 'Lopez', 4),
('EMP04', 'Juan', 'Perez', 4),
('EMP05', 'Ivan', 'Lopez', 1),
('EMP06', 'Margarita', 'Hernandez', 1),
('EMP07', 'Jesus', 'Perez', 3),
('EMP08', 'Jonathan', 'Flores', 2),
('EMP09', 'Pablo', 'Hernandez', 4),
('EMP010', 'Ana', 'Gonzalez', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`clave`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`clave`,`clavDep`),
  ADD KEY `emleado` (`clavDep`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
  MODIFY `clave` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
