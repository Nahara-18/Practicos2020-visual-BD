﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.imc = New System.Windows.Forms.Button()
        Me.peso = New System.Windows.Forms.TextBox()
        Me.button1 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Label()
        Me.altura = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.fisica = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.mate = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.quimica = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.biologia = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.derecho = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.H = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'imc
        '
        Me.imc.Location = New System.Drawing.Point(12, 266)
        Me.imc.Name = "imc"
        Me.imc.Size = New System.Drawing.Size(137, 31)
        Me.imc.TabIndex = 0
        Me.imc.Text = "IMC"
        Me.imc.UseVisualStyleBackColor = True
        '
        'peso
        '
        Me.peso.Location = New System.Drawing.Point(25, 159)
        Me.peso.Name = "peso"
        Me.peso.Size = New System.Drawing.Size(119, 20)
        Me.peso.TabIndex = 1
        '
        'button1
        '
        Me.button1.AutoSize = True
        Me.button1.Location = New System.Drawing.Point(43, 131)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(31, 13)
        Me.button1.TabIndex = 2
        Me.button1.Text = "Peso"
        '
        'button2
        '
        Me.button2.AutoSize = True
        Me.button2.Location = New System.Drawing.Point(43, 195)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(34, 13)
        Me.button2.TabIndex = 4
        Me.button2.Text = "Altura"
        '
        'altura
        '
        Me.altura.Location = New System.Drawing.Point(25, 225)
        Me.altura.Name = "altura"
        Me.altura.Size = New System.Drawing.Size(119, 20)
        Me.altura.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Mistral", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(152, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 26)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Ejercicios - primeras clases"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(196, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Fisica"
        '
        'fisica
        '
        Me.fisica.Location = New System.Drawing.Point(178, 162)
        Me.fisica.Name = "fisica"
        Me.fisica.Size = New System.Drawing.Size(125, 20)
        Me.fisica.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(196, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Mate"
        '
        'mate
        '
        Me.mate.Location = New System.Drawing.Point(178, 123)
        Me.mate.Name = "mate"
        Me.mate.Size = New System.Drawing.Size(125, 20)
        Me.mate.TabIndex = 9
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(178, 320)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(137, 31)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "Promedio"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(196, 228)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "quimica"
        '
        'quimica
        '
        Me.quimica.Location = New System.Drawing.Point(178, 244)
        Me.quimica.Name = "quimica"
        Me.quimica.Size = New System.Drawing.Size(125, 20)
        Me.quimica.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(196, 186)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Biologia"
        '
        'biologia
        '
        Me.biologia.Location = New System.Drawing.Point(178, 202)
        Me.biologia.Name = "biologia"
        Me.biologia.Size = New System.Drawing.Size(125, 20)
        Me.biologia.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(196, 266)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "derecho"
        '
        'derecho
        '
        Me.derecho.Location = New System.Drawing.Point(178, 282)
        Me.derecho.Name = "derecho"
        Me.derecho.Size = New System.Drawing.Size(125, 20)
        Me.derecho.TabIndex = 17
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(362, 212)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(30, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Hora"
        '
        'H
        '
        Me.H.Location = New System.Drawing.Point(344, 228)
        Me.H.Name = "H"
        Me.H.Size = New System.Drawing.Size(125, 20)
        Me.H.TabIndex = 20
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(344, 266)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(137, 31)
        Me.Button4.TabIndex = 19
        Me.Button4.Text = "Horario de:"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(12, 12)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(81, 17)
        Me.CheckBox1.TabIndex = 22
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(500, 382)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.H)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.derecho)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.quimica)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.biologia)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.fisica)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.mate)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.altura)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.peso)
        Me.Controls.Add(Me.imc)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents imc As Button
    Friend WithEvents peso As TextBox
    Friend WithEvents button1 As Label
    Friend WithEvents button2 As Label
    Friend WithEvents altura As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents fisica As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents mate As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents quimica As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents biologia As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents derecho As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents H As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents CheckBox1 As CheckBox
End Class
