﻿Public Class Form1
    Private Sub imc_Click(sender As Object, e As EventArgs) Handles imc.Click
        Dim multi, imc As Double
        multi = altura.Text * altura.Text
        imc = peso.Text / multi
        If imc <= 18.49 Then
            MsgBox("Infrapeso")
        ElseIf imc >= 18.5 And imc <= 24.99 Then
            MsgBox("Peso Normal")
        ElseIf imc >= 25.0 And imc <= 29.99 Then
            MsgBox("Sobrepeso")
        Else
            MsgBox("Obeso")

        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim suma, promedio As Double
        suma = mate.Text + fisica.Text + quimica.Text + biologia.Text + derecho.Text
        promedio = suma / 5
        If promedio >= 1 And promedio <= 2 Then
            MsgBox("Examen a febrero")
        ElseIf promedio >= 3 And promedio <= 6 Then
            MsgBox("Examen a diciembre")
        ElseIf promedio >= 7 And promedio <= 11 Then
            MsgBox("Aprobado")
        ElseIf promedio = 12 Then
            MsgBox("Aprobado con onores")
        Else
            MsgBox("Error")

        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Select Case H.Text
            Case 7.0 To 9.59
                MsgBox("Desayuno")
            Case 10.0 To 14.59
                MsgBox("Almuerzo")
            Case 15.0 To 18.59
                MsgBox("Merienda")
            Case 19.0 To 22.59
                MsgBox("Cena")
            Case Else
                MsgBox("Esta Cerrado")
        End Select
    End Sub


End Class
