﻿Public Class Form1
    Dim peso, altura, multi, IMC As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        peso = p.Text
        altura = a.Text
        multi = altura * altura
        IMC = peso / multi
        If (IMC < 18.5) Then
            resultado.Text = "Infrapeso"
        ElseIf (IMC >= 18.5 And IMC < 25.0) Then
            resultado.Text = "Peso Normal"
        ElseIf (IMC >= 25.0 And IMC <= 30.0) Then
            resultado.Text = "Sobrepeso"
        Else
            resultado.Text = "Obeso"
        End If
    End Sub
End Class
