﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function con()
        co = New OdbcConnection("Dsn=Usuario")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    Sub alta()
        Call con()
        If Form1.CI.Text = "" Or Form1.N.Text = "" Or Form1.C.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                cmd = New OdbcCommand("Insert into persona values('" & Form1.CI.Text & "','" & Form1.N.Text & "'," & Form1.C.Text & ")", co)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Form1.CI.Text = ""
                Form1.N.Text = ""
                Form1.C.Text = ""
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
End Module
