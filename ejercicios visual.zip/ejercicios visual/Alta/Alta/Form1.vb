﻿
Public Class Form1
    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Modulo.alta()
    End Sub

    Private Sub N_KeyPress(sender As Object, e As KeyPressEventArgs) Handles N.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub CI_KeyPress(sender As Object, e As KeyPressEventArgs) Handles CI.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub C_KeyPress(sender As Object, e As KeyPressEventArgs) Handles C.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class
