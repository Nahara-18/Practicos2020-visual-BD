﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.N = New System.Windows.Forms.CheckBox()
        Me.C = New System.Windows.Forms.CheckBox()
        Me.S = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.asddas = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Texto = New System.Windows.Forms.TextBox()
        Me.CA = New System.Windows.Forms.TextBox()
        Me.CE = New System.Windows.Forms.TextBox()
        Me.CI = New System.Windows.Forms.TextBox()
        Me.CO = New System.Windows.Forms.TextBox()
        Me.CU = New System.Windows.Forms.TextBox()
        Me.CT = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Min = New System.Windows.Forms.RadioButton()
        Me.May = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Re = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Ne = New System.Windows.Forms.RadioButton()
        Me.A = New System.Windows.Forms.RadioButton()
        Me.V = New System.Windows.Forms.RadioButton()
        Me.R = New System.Windows.Forms.RadioButton()
        Me.CL = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(60, 87)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(578, 24)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Evaluar caracteres"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N.Location = New System.Drawing.Point(31, 19)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(67, 17)
        Me.N.TabIndex = 1
        Me.N.Text = "Negrita"
        Me.N.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C.Location = New System.Drawing.Point(31, 42)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(61, 17)
        Me.C.TabIndex = 2
        Me.C.Text = "Cursiva"
        Me.C.UseVisualStyleBackColor = True
        '
        'S
        '
        Me.S.AutoSize = True
        Me.S.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.S.Location = New System.Drawing.Point(31, 65)
        Me.S.Name = "S"
        Me.S.Size = New System.Drawing.Size(77, 17)
        Me.S.TabIndex = 3
        Me.S.Text = "Subrayada"
        Me.S.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(57, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Cadena de texto"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(57, 203)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Cant. a"
        '
        'asddas
        '
        Me.asddas.AutoSize = True
        Me.asddas.Location = New System.Drawing.Point(173, 203)
        Me.asddas.Name = "asddas"
        Me.asddas.Size = New System.Drawing.Size(41, 13)
        Me.asddas.TabIndex = 6
        Me.asddas.Text = "Cant. e"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(414, 203)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Cant. o"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(295, 203)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Cant. i"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(552, 205)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Cant. u"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(101, 153)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(127, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Cantidad total de vocales"
        '
        'Texto
        '
        Me.Texto.Location = New System.Drawing.Point(60, 53)
        Me.Texto.Name = "Texto"
        Me.Texto.Size = New System.Drawing.Size(578, 20)
        Me.Texto.TabIndex = 19
        '
        'CA
        '
        Me.CA.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CA.Location = New System.Drawing.Point(104, 200)
        Me.CA.Name = "CA"
        Me.CA.Size = New System.Drawing.Size(39, 20)
        Me.CA.TabIndex = 20
        '
        'CE
        '
        Me.CE.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CE.Location = New System.Drawing.Point(220, 200)
        Me.CE.Name = "CE"
        Me.CE.Size = New System.Drawing.Size(39, 20)
        Me.CE.TabIndex = 21
        '
        'CI
        '
        Me.CI.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CI.Location = New System.Drawing.Point(338, 200)
        Me.CI.Name = "CI"
        Me.CI.Size = New System.Drawing.Size(39, 20)
        Me.CI.TabIndex = 22
        '
        'CO
        '
        Me.CO.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CO.Location = New System.Drawing.Point(461, 200)
        Me.CO.Name = "CO"
        Me.CO.Size = New System.Drawing.Size(39, 20)
        Me.CO.TabIndex = 23
        '
        'CU
        '
        Me.CU.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CU.Location = New System.Drawing.Point(599, 203)
        Me.CU.Name = "CU"
        Me.CU.Size = New System.Drawing.Size(39, 20)
        Me.CU.TabIndex = 24
        '
        'CT
        '
        Me.CT.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CT.Location = New System.Drawing.Point(234, 150)
        Me.CT.Name = "CT"
        Me.CT.Size = New System.Drawing.Size(39, 20)
        Me.CT.TabIndex = 25
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Min)
        Me.GroupBox1.Controls.Add(Me.May)
        Me.GroupBox1.Location = New System.Drawing.Point(61, 247)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(123, 81)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Convertir a"
        '
        'Min
        '
        Me.Min.AutoSize = True
        Me.Min.Location = New System.Drawing.Point(17, 50)
        Me.Min.Name = "Min"
        Me.Min.Size = New System.Drawing.Size(77, 17)
        Me.Min.TabIndex = 1
        Me.Min.TabStop = True
        Me.Min.Text = "minusculas"
        Me.Min.UseVisualStyleBackColor = True
        '
        'May
        '
        Me.May.AutoSize = True
        Me.May.Location = New System.Drawing.Point(17, 27)
        Me.May.Name = "May"
        Me.May.Size = New System.Drawing.Size(91, 17)
        Me.May.TabIndex = 0
        Me.May.TabStop = True
        Me.May.Text = "MAUSCULAS"
        Me.May.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox2.Controls.Add(Me.Re)
        Me.GroupBox2.Controls.Add(Me.N)
        Me.GroupBox2.Controls.Add(Me.C)
        Me.GroupBox2.Controls.Add(Me.S)
        Me.GroupBox2.Location = New System.Drawing.Point(274, 247)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(150, 124)
        Me.GroupBox2.TabIndex = 27
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Formato"
        '
        'Re
        '
        Me.Re.AutoSize = True
        Me.Re.Location = New System.Drawing.Point(31, 88)
        Me.Re.Name = "Re"
        Me.Re.Size = New System.Drawing.Size(83, 17)
        Me.Re.TabIndex = 4
        Me.Re.Text = "Restablecer"
        Me.Re.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox3.Controls.Add(Me.Ne)
        Me.GroupBox3.Controls.Add(Me.A)
        Me.GroupBox3.Controls.Add(Me.V)
        Me.GroupBox3.Controls.Add(Me.R)
        Me.GroupBox3.Location = New System.Drawing.Point(519, 247)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(107, 124)
        Me.GroupBox3.TabIndex = 28
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Color"
        '
        'Ne
        '
        Me.Ne.AutoSize = True
        Me.Ne.Location = New System.Drawing.Point(23, 88)
        Me.Ne.Name = "Ne"
        Me.Ne.Size = New System.Drawing.Size(54, 17)
        Me.Ne.TabIndex = 3
        Me.Ne.TabStop = True
        Me.Ne.Text = "Negro"
        Me.Ne.UseVisualStyleBackColor = True
        '
        'A
        '
        Me.A.AutoSize = True
        Me.A.ForeColor = System.Drawing.Color.MediumBlue
        Me.A.Location = New System.Drawing.Point(23, 65)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(45, 17)
        Me.A.TabIndex = 2
        Me.A.TabStop = True
        Me.A.Text = "Azul"
        Me.A.UseVisualStyleBackColor = True
        '
        'V
        '
        Me.V.AutoSize = True
        Me.V.ForeColor = System.Drawing.Color.LimeGreen
        Me.V.Location = New System.Drawing.Point(23, 42)
        Me.V.Name = "V"
        Me.V.Size = New System.Drawing.Size(53, 17)
        Me.V.TabIndex = 1
        Me.V.TabStop = True
        Me.V.Text = "Verde"
        Me.V.UseVisualStyleBackColor = True
        '
        'R
        '
        Me.R.AutoSize = True
        Me.R.ForeColor = System.Drawing.Color.Red
        Me.R.Location = New System.Drawing.Point(23, 19)
        Me.R.Name = "R"
        Me.R.Size = New System.Drawing.Size(47, 17)
        Me.R.TabIndex = 0
        Me.R.TabStop = True
        Me.R.Text = "Rojo"
        Me.R.UseVisualStyleBackColor = True
        '
        'CL
        '
        Me.CL.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CL.Location = New System.Drawing.Point(557, 150)
        Me.CL.Name = "CL"
        Me.CL.Size = New System.Drawing.Size(39, 20)
        Me.CL.TabIndex = 30
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(424, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Cantidad total de letras"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(706, 383)
        Me.Controls.Add(Me.CL)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CT)
        Me.Controls.Add(Me.CU)
        Me.Controls.Add(Me.CO)
        Me.Controls.Add(Me.CI)
        Me.Controls.Add(Me.CE)
        Me.Controls.Add(Me.CA)
        Me.Controls.Add(Me.Texto)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.asddas)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Vocales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents N As CheckBox
    Friend WithEvents C As CheckBox
    Friend WithEvents S As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents asddas As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Texto As TextBox
    Friend WithEvents CA As TextBox
    Friend WithEvents CE As TextBox
    Friend WithEvents CI As TextBox
    Friend WithEvents CO As TextBox
    Friend WithEvents CU As TextBox
    Friend WithEvents CT As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Min As RadioButton
    Friend WithEvents May As RadioButton
    Friend WithEvents A As RadioButton
    Friend WithEvents V As RadioButton
    Friend WithEvents R As RadioButton
    Friend WithEvents Re As CheckBox
    Friend WithEvents Ne As RadioButton
    Friend WithEvents CL As TextBox
    Friend WithEvents Label3 As Label
End Class
