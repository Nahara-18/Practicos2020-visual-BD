﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim t As String = Texto.Text
        Dim num, pos, veces, x, a, ee, i, o, u As Integer
        Dim caracter As String
        pos = 1
        veces = 0
        x = 0
        a = 0
        ee = 0
        i = 0
        o = 0
        u = 0
        num = Len(t)


        While (veces <= num)
            caracter = Mid(t, pos, 1)
            If (caracter = "a" Or caracter = "A") Then
                x += 1
                a += 1
            ElseIf (caracter = "e" Or caracter = "E") Then
                x += 1
                ee += 1
            ElseIf (caracter = "i" Or caracter = "I") Then
                x += 1
                i += 1
            ElseIf (caracter = "o" Or caracter = "O") Then
                x += 1
                o += 1
            ElseIf (caracter = "u" Or caracter = "U") Then
                x += 1
                u += 1
            End If
            pos += 1
            veces += 1
        End While
        CL.Text = num
        CT.Text = x
        CA.Text = a
        CE.Text = ee
        CI.Text = i
        CO.Text = o
        CU.Text = u
    End Sub


    Private Sub May_CheckedChanged(sender As Object, e As EventArgs) Handles May.CheckedChanged
        Dim t As String = Texto.Text
        Texto.Text = UCase(t)
    End Sub

    Private Sub Min_CheckedChanged(sender As Object, e As EventArgs) Handles Min.CheckedChanged
        Dim t As String = Texto.Text
        Texto.Text = LCase(t)
    End Sub

    Private Sub R_CheckedChanged(sender As Object, e As EventArgs) Handles R.CheckedChanged
        If (R.Checked = True) Then
            Texto.ForeColor = ForeColor.Red
        End If
    End Sub

    Private Sub V_CheckedChanged(sender As Object, e As EventArgs) Handles V.CheckedChanged
        If (V.Checked = True) Then
            Texto.ForeColor = ForeColor.LimeGreen
        End If
    End Sub

    Private Sub A_CheckedChanged(sender As Object, e As EventArgs) Handles A.CheckedChanged
        If (A.Checked = True) Then
            Texto.ForeColor = ForeColor.MediumBlue
        End If
    End Sub
    Private Sub Ne_CheckedChanged(sender As Object, e As EventArgs) Handles Ne.CheckedChanged
        If (Ne.Checked = True) Then
            Texto.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub N_CheckedChanged(sender As Object, e As EventArgs) Handles N.CheckedChanged
        If (N.Checked = True And C.Checked = False And S.Checked = False) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold)
        ElseIf (N.Checked = True And C.Checked = False And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Underline)
        ElseIf (N.Checked = True And C.Checked = True And S.Checked = False) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Italic)
        ElseIf (N.Checked = True And C.Checked = True And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline)

        End If
    End Sub

    Private Sub C_CheckedChanged(sender As Object, e As EventArgs) Handles C.CheckedChanged
        If (N.Checked = False And C.Checked = True And S.Checked = False) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Italic)
        ElseIf (N.Checked = False And C.Checked = True And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Italic Or FontStyle.Underline)
        ElseIf (N.Checked = True And C.Checked = True And S.Checked = False) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Italic)
        ElseIf (N.Checked = True And C.Checked = True And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline)

        End If
    End Sub

    Private Sub S_CheckedChanged(sender As Object, e As EventArgs) Handles S.CheckedChanged
        If (N.Checked = False And C.Checked = False And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Underline)
        ElseIf (N.Checked = True And C.Checked = False And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Underline)
        ElseIf (N.Checked = False And C.Checked = True And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Underline Or FontStyle.Italic)
        ElseIf (N.Checked = True And C.Checked = True And S.Checked = True) Then
            Texto.Font = New Font("Microsoft Sans Serif", 8.25, FontStyle.Bold Or FontStyle.Italic Or FontStyle.Underline)
       
        End If
    End Sub

    Private Sub Re_CheckedChanged(sender As Object, e As EventArgs) Handles Re.CheckedChanged
        Texto.Font = New Font("Microsoft Sans Serif", 8.25)

    End Sub
End Class
