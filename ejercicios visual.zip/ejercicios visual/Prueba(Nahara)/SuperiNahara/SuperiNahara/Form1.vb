﻿Imports System.Data.Odbc
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conexion As New OdbcConnection
        Dim command As New OdbcCommand

        conexion = New OdbcConnection("Dsn=Prueba")
        If conexion.State = ConnectionState.Closed Then
            conexion.Open()
        Else
            MsgBox("Ups! No se pudo conectar!")
        End If

        command = New OdbcCommand("SELECT * FROM cliente
                                WHERE clave = '" & ci.Text & "'
                                AND nombre = '" & clave.Text & "'", conexion)

        If (command.ExecuteScalar()) Then
            MsgBox("Login Ok!")
        Else
            Form2.Visible = True
        End If
    End Sub
End Class
