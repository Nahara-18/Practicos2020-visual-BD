﻿Public Class Form1


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim clas As New Clase()
        clas.n = nombre.Text
        clas.c = contraseña.Text
        If (tipo.Text = "admin") Then
            clas.t = "Admin"
        ElseIf (tipo.Text = "service") Then
            clas.t = "reportes"
        ElseIf (tipo.Text = "reportes") Then
            clas.t = "reportes"
        End If
        MsgBox("Bienvenido " & clas.n & ", sos " & clas.t)

    End Sub



    Private Sub nombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub contraseña_KeyPress(sender As Object, e As KeyPressEventArgs) Handles contraseña.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class
