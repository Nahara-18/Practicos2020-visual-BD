﻿Public Class Clase
    Private nom, con, tipo As String

    Public Property n() As String
        Get
            Return nom
        End Get
        Set(n As String)
            nom = n
        End Set
    End Property

    Public Property c() As String
        Get
            Return con
        End Get
        Set(co As String)
            con = co
        End Set
    End Property

    Public Property t() As String
        Get
            Return tipo
        End Get
        Set(ti As String)
            tipo = ti
        End Set
    End Property

End Class
