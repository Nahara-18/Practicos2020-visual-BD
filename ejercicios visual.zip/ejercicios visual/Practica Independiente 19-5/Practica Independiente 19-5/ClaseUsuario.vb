﻿Public Class ClaseUsuario
    Private id As Integer
    Private nombre As String
    Private email As String
    Private contraseña As String

    Public Property IngId() As Integer
        Get
            Return id
        End Get
        Set(ingid As Integer)
            id = ingid
        End Set
    End Property
    Public Property ingNombre() As String
        Get
            Return nombre
        End Get
        Set(ingnom As String)
            nombre = ingnom
        End Set
    End Property
    Public Property ingEmail() As String
        Get
            Return email
        End Get
        Set(ingem As String)
            email = ingem
        End Set
    End Property
    Public Property ingContra() As String
        Get
            Return contraseña
        End Get
        Set(ingcont As String)
            contraseña = ingcont
        End Set
    End Property

End Class
