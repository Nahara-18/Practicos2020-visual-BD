﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Usuario As New ClaseUsuario()

        Usuario.IngId = IngreId.Text
        Usuario.ingNombre = IngreNombre.Text
        Usuario.ingEmail = IngreEmail.Text
        Usuario.ingContra = IngreContra.Text

        MsgBox("ID:" & Usuario.IngId & " NOMBRE:" & Usuario.ingNombre & " EMAIL:" & Usuario.ingEmail & " CONTRASEÑA:" & Usuario.ingContra)
    End Sub
End Class
