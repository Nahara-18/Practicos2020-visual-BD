﻿Public Class Eje3
    Private Sub btnCon_Click(sender As Object, e As EventArgs) Handles btnCon.Click
        MsgBox(Modulo1.Celsius(ingreso.Text))
    End Sub
End Class