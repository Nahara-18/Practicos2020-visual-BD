﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Eje2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDefF = New System.Windows.Forms.Button()
        Me.definicion = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnDefF
        '
        Me.btnDefF.Location = New System.Drawing.Point(104, 45)
        Me.btnDefF.Name = "btnDefF"
        Me.btnDefF.Size = New System.Drawing.Size(101, 23)
        Me.btnDefF.TabIndex = 0
        Me.btnDefF.Text = "Definir funcion"
        Me.btnDefF.UseVisualStyleBackColor = True
        '
        'definicion
        '
        Me.definicion.AutoSize = True
        Me.definicion.Location = New System.Drawing.Point(12, 101)
        Me.definicion.Name = "definicion"
        Me.definicion.Size = New System.Drawing.Size(65, 13)
        Me.definicion.TabIndex = 1
        Me.definicion.Text = "Mostrar aqui"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(336, 180)
        Me.Controls.Add(Me.definicion)
        Me.Controls.Add(Me.btnDefF)
        Me.Name = "Form2"
        Me.Text = "Eje2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnDefF As Button
    Friend WithEvents definicion As Label
End Class
