﻿Public Class Eje1
    Private Sub btnDef_Click(sender As Object, e As EventArgs) Handles btnDef.Click
        Modulo1.def()
    End Sub
End Class
