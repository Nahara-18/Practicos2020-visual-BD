﻿Module Modulo1
    Sub def()
        MsgBox("Porcion de codigo dentro de un programa, que realiza una tarea especifica")
    End Sub

    Function defFuncion()
        Dim def As String = "Una funcion es un conjunto de lineas de codigo que realizan" & vbNewLine & "una tarea especifica y retornan un valor"
        Return def
    End Function

    Function Celsius(i As Double)
        Dim res As Double
        res = (i * 1.8) + 32
        Return res
    End Function
End Module
