﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ejercicio9
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.tabla = New System.Windows.Forms.DataGridView()
        Me.Multi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Multipli = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Res = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.N = New System.Windows.Forms.TextBox()
        CType(Me.tabla, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(228, 25)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(109, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Mostrar Tabla"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'tabla
        '
        Me.tabla.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.tabla.BackgroundColor = System.Drawing.Color.SkyBlue
        Me.tabla.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.tabla.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tabla.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Multi, Me.Multipli, Me.Res})
        Me.tabla.Enabled = False
        Me.tabla.EnableHeadersVisualStyles = False
        Me.tabla.Location = New System.Drawing.Point(25, 82)
        Me.tabla.Name = "tabla"
        Me.tabla.Size = New System.Drawing.Size(345, 242)
        Me.tabla.TabIndex = 1
        '
        'Multi
        '
        Me.Multi.HeaderText = "Multiplicando"
        Me.Multi.Name = "Multi"
        '
        'Multipli
        '
        Me.Multipli.HeaderText = "Multiplicador"
        Me.Multipli.Name = "Multipli"
        '
        'Res
        '
        Me.Res.HeaderText = "Resultado"
        Me.Res.Name = "Res"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Numero"
        '
        'N
        '
        Me.N.Location = New System.Drawing.Point(97, 27)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(100, 20)
        Me.N.TabIndex = 3
        '
        'Ejercicio9
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ClientSize = New System.Drawing.Size(400, 444)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tabla)
        Me.Controls.Add(Me.Button1)
        Me.MaximizeBox = False
        Me.Name = "Ejercicio9"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ejercicio9"
        CType(Me.tabla, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents tabla As DataGridView
    Friend WithEvents Multi As DataGridViewTextBoxColumn
    Friend WithEvents Multipli As DataGridViewTextBoxColumn
    Friend WithEvents Res As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents N As TextBox
End Class
