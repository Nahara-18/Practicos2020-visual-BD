﻿Public Class Form1

    Private Sub l_SelectedIndexChanged(sender As Object, e As EventArgs) Handles l.SelectedIndexChanged
        'Argentina
        'Brasil
        'Chile
        Me.l.Items.Add("Montevideo")
        l.
    End Sub

    Private Sub l1_Click(sender As Object, e As EventArgs) Handles l1.Click
        l1.Text = p.Text
    End Sub

End Class
