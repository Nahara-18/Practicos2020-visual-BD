﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.l1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.p = New System.Windows.Forms.ComboBox()
        Me.l = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'l1
        '
        Me.l1.AutoSize = True
        Me.l1.Location = New System.Drawing.Point(61, 60)
        Me.l1.Name = "l1"
        Me.l1.Size = New System.Drawing.Size(27, 13)
        Me.l1.TabIndex = 0
        Me.l1.Text = "Pais"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(61, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Localidad"
        '
        'p
        '
        Me.p.FormattingEnabled = True
        Me.p.Items.AddRange(New Object() {"Uruguay", "Argentina", "Brasil", "Chile"})
        Me.p.Location = New System.Drawing.Point(137, 57)
        Me.p.Name = "p"
        Me.p.Size = New System.Drawing.Size(121, 21)
        Me.p.TabIndex = 2
        '
        'l
        '
        Me.l.FormattingEnabled = True
        Me.l.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.l.Location = New System.Drawing.Point(137, 114)
        Me.l.Name = "l"
        Me.l.Size = New System.Drawing.Size(121, 21)
        Me.l.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(377, 219)
        Me.Controls.Add(Me.l)
        Me.Controls.Add(Me.p)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.l1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents l1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents p As ComboBox
    Friend WithEvents l As ComboBox
End Class
