﻿Public Class Form1
    Dim parte1, parte2, parte3 As String
    Private Sub Mostrar_Click(sender As Object, e As EventArgs) Handles Mostrar.Click
        parte1 = f1.Text
        parte2 = f2.Text
        parte3 = f3.Text
        MsgBox(parte1 + " " + parte2 + " " + parte3)

    End Sub
End Class
