﻿Module Modulo

    Function multi(num As Double)
        Dim resultado, resta As Double
        If (num < 3) Then
            resultado = num * 60
            Return resultado
        ElseIf (num >= 3 And num < 10) Then
            resultado = num * 60
            resta = resultado - reglaDEtres3L(resultado)
            Return resta
        Else
            resultado = num * 60
            resta = resultado - reglaDEtres10L(resultado)
            Return resta
        End If
    End Function

    Function reglaDEtres3L(numero As Double)
        Dim cuenta As Double
        cuenta = numero * 7 / 100
        Return cuenta
    End Function
    Function reglaDEtres10L(numero As Double)
        Dim cuenta As Double
        cuenta = numero * 15 / 100
        Return cuenta
    End Function
End Module
