﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.u1 = New System.Windows.Forms.Label()
        Me.c1 = New System.Windows.Forms.Label()
        Me.mos = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.u = New System.Windows.Forms.TextBox()
        Me.c = New System.Windows.Forms.TextBox()
        Me.corUsu = New System.Windows.Forms.Label()
        Me.corCon = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'u1
        '
        Me.u1.AutoSize = True
        Me.u1.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.u1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.u1.Location = New System.Drawing.Point(57, 48)
        Me.u1.Name = "u1"
        Me.u1.Size = New System.Drawing.Size(61, 20)
        Me.u1.TabIndex = 0
        Me.u1.Text = "Usuario"
        '
        'c1
        '
        Me.c1.AutoSize = True
        Me.c1.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.c1.Location = New System.Drawing.Point(41, 86)
        Me.c1.Name = "c1"
        Me.c1.Size = New System.Drawing.Size(84, 20)
        Me.c1.TabIndex = 1
        Me.c1.Text = "Contraseña"
        '
        'mos
        '
        Me.mos.AutoSize = True
        Me.mos.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mos.Location = New System.Drawing.Point(132, 121)
        Me.mos.Name = "mos"
        Me.mos.Size = New System.Drawing.Size(122, 20)
        Me.mos.TabIndex = 2
        Me.mos.Text = "Mostrar contraseña"
        Me.mos.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(147, 165)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 28)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Ingresar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'u
        '
        Me.u.Location = New System.Drawing.Point(132, 48)
        Me.u.Name = "u"
        Me.u.Size = New System.Drawing.Size(100, 20)
        Me.u.TabIndex = 4
        '
        'c
        '
        Me.c.Location = New System.Drawing.Point(132, 86)
        Me.c.Name = "c"
        Me.c.Size = New System.Drawing.Size(100, 20)
        Me.c.TabIndex = 5
        Me.c.UseSystemPasswordChar = True
        '
        'corUsu
        '
        Me.corUsu.AutoSize = True
        Me.corUsu.Location = New System.Drawing.Point(238, 48)
        Me.corUsu.Name = "corUsu"
        Me.corUsu.Size = New System.Drawing.Size(0, 13)
        Me.corUsu.TabIndex = 6
        '
        'corCon
        '
        Me.corCon.AutoSize = True
        Me.corCon.Location = New System.Drawing.Point(238, 89)
        Me.corCon.Name = "corCon"
        Me.corCon.Size = New System.Drawing.Size(0, 13)
        Me.corCon.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(406, 242)
        Me.Controls.Add(Me.corCon)
        Me.Controls.Add(Me.corUsu)
        Me.Controls.Add(Me.c)
        Me.Controls.Add(Me.u)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.mos)
        Me.Controls.Add(Me.c1)
        Me.Controls.Add(Me.u1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inicio de seción"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents u1 As Label
    Friend WithEvents c1 As Label
    Friend WithEvents mos As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents u As TextBox
    Friend WithEvents c As TextBox
    Friend WithEvents corUsu As Label
    Friend WithEvents corCon As Label
End Class
