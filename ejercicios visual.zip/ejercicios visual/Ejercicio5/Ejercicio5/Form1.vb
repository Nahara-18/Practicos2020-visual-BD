﻿Public Class Form1
    Dim usu As String
    Dim con As Integer
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        usu = u.Text
        con = Val(c.Text)
        corUsu.Text = ""
        corCon.Text = ""
        u1.ForeColor = ForeColor.Black
        c1.ForeColor = ForeColor.Black

        Dim num, pos, veces, caract, x As Integer
        Dim caracter As String
        x = 1
        pos = 1
        veces = 0
        num = Len(con)

        While (veces <= num And x = 1)
            caracter = Mid(con, pos, 1)
            caract = Val(caracter)
            If (caract < 1 Or caract > 9) Then
                x = 0
            End If
            pos += 1
            veces += 1
        End While

        If (Len(usu) = 0 And con = 0) Then
            u1.ForeColor = ForeColor.Red
            c1.ForeColor = ForeColor.Red
            corUsu.Text = "El usuario tiene que tener entre" & vbNewLine & " 6 y 9 caracteres"
            corCon.Text = "No puede estar vacio y solo debe" & vbNewLine & " contener números"

        ElseIf (Len(usu) < 5 Or Len(usu) > 9) Then
            u1.ForeColor = ForeColor.Red
            corUsu.Text = "Tiene que tener entre 6 y 9 caracteres"

        ElseIf (con = 0 Or x = 0) Then
            c1.ForeColor = ForeColor.Red
            corCon.Text = "No puede estar vacio y solo debe" & vbNewLine & " contener números"

        Else
            MsgBox("Bienvenido " & usu)
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles mos.CheckedChanged
        If (mos.Checked = True) Then
            c.UseSystemPasswordChar = False
        ElseIf (mos.Checked = False) Then
            c.UseSystemPasswordChar = True
        End If
    End Sub


End Class
