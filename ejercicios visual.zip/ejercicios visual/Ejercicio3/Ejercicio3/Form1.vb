﻿Public Class Form1
    Dim nom, ape, se, M As String
    Dim edad As Integer
    Dim alt As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        nom = n.Text
        ape = a.Text
        edad = ed.Text
        If (s.Text = "F") Then
            se = "Femenino"
        ElseIf (s.text = "M") Then
            se = "Masculino"
        Else
            se = "indeterminado"
        End If
        alt = al.Text
        If (edad < 18) Then
            M = "Menor"
        Else
            M = "Mayor"
        End If

        MsgBox(ape & "," & nom & " Tiene " & edad & " años.Su sexo es " & se & " y mide " & alt & "m de estatura." & vbNewLine & "Esta persona es " & M)



    End Sub
End Class
