﻿Imports System.Data.Odbc

Public Class Form1
    Public cx As Odbc.OdbcConnection

    Sub conexion()
        cx = New OdbcConnection("Dsn=prueba1")
        If cx.State = ConnectionState.Closed Then
            cx.Open()
            MsgBox("Conexion Exitosa")
        Else
            MsgBox("Error")
        End If
    End Sub
    Private Sub p_Click(sender As Object, e As EventArgs) Handles i.Click
        Call conexion()
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim u As String = usu.Text
        Dim c As String = cla.Text
        If u = "" Or c = "" Then
            MessageBox.Show("Debe completar todos los campos", "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If login(u, c) = 1 Then
                MessageBox.Show("Datos correctos", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Form2.Visible = True

            Else
                MessageBox.Show("Usuario y/o clave incorreca", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        End If
    End Sub
End Class
