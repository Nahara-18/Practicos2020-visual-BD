﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function con()
        co = New OdbcConnection("Dsn=prueba1")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function

    Function login(usuario, clave)
        Call con()
        cmd = New OdbcCommand("SELECT COUNT(*) FROM login  WHERE usuNombre = '" & usuario & "'  AND usuClave = '" & clave & "'", co)
        Return cmd.ExecuteScalar()
    End Function

    Sub listar()
        Call con()
        ada = New OdbcDataAdapter("Select usuClave AS Clave , usuNombre AS Nombre , edad AS Edad FROM login", co)
        ds = New DataSet()
        ada.Fill(ds)
        Form2.listadoUsuario.DataSource = ds.Tables(0)
        Form2.listadoUsuario.Columns("Clave").Width = 60
        Form2.listadoUsuario.Columns("Nombre").Width = 80
        Form2.listadoUsuario.Columns("Edad").Width = 100
    End Sub
End Module
