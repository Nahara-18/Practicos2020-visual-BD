﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand

    Function con()
        co = New OdbcConnection("Dsn=prueba1")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    Function login(usuario, clave)
        Call con()
        cmd = New OdbcCommand("SELECT COUNT(*) FROM login  WHERE usuNombre = '" & usuario & "'  AND usuClave = '" & clave & "'", co)
        Return cmd.ExecuteScalar()
    End Function
End Module
