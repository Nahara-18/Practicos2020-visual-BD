﻿Imports System.Data.Odbc
Public Class Form2
    Private Sub listadoUsuario_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles listadoUsuario.CellContentClick
        Modulo.listar()
    End Sub
End Class