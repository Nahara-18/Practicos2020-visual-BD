﻿Public Class Form1
    Dim num1, num2, suma, resta, multi As Integer
    Dim divi As Double

    Private Sub D_Click(sender As Object, e As EventArgs) Handles D.Click
        num1 = n1.Text
        num2 = n2.Text
        divi = num1 / num2
        MsgBox("El resultado de la divición es: " & divi)
    End Sub

    Private Sub M_Click(sender As Object, e As EventArgs) Handles M.Click
        num1 = n1.Text
        num2 = n2.Text
        multi = num1 * num2
        MsgBox("El resultado de la multiplicación es: " & multi)
    End Sub

    Private Sub R_Click(sender As Object, e As EventArgs) Handles R.Click
        num1 = n1.Text
        num2 = n2.Text
        resta = num1 - num2
        MsgBox("El resultado de la resta es: " & resta)
    End Sub

    Private Sub S_Click(sender As Object, e As EventArgs) Handles S.Click
        num1 = n1.Text
        num2 = n2.Text
        suma = num1 + num2
        MsgBox("El resultado de la suma es: " & suma)
    End Sub
End Class
