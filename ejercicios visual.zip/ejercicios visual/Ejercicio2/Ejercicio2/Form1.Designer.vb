﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.n2 = New System.Windows.Forms.TextBox()
        Me.n1 = New System.Windows.Forms.TextBox()
        Me.S = New System.Windows.Forms.Button()
        Me.R = New System.Windows.Forms.Button()
        Me.M = New System.Windows.Forms.Button()
        Me.D = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bauhaus 93", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(53, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Numero 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bauhaus 93", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(260, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Numero 2"
        '
        'n2
        '
        Me.n2.Location = New System.Drawing.Point(319, 58)
        Me.n2.Name = "n2"
        Me.n2.Size = New System.Drawing.Size(91, 20)
        Me.n2.TabIndex = 2
        '
        'n1
        '
        Me.n1.Location = New System.Drawing.Point(112, 58)
        Me.n1.Name = "n1"
        Me.n1.Size = New System.Drawing.Size(91, 20)
        Me.n1.TabIndex = 3
        '
        'S
        '
        Me.S.Font = New System.Drawing.Font("Bauhaus 93", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.S.Location = New System.Drawing.Point(38, 122)
        Me.S.Name = "S"
        Me.S.Size = New System.Drawing.Size(75, 31)
        Me.S.TabIndex = 4
        Me.S.Text = "Suma"
        Me.S.UseVisualStyleBackColor = True
        '
        'R
        '
        Me.R.Font = New System.Drawing.Font("Bauhaus 93", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.R.Location = New System.Drawing.Point(128, 122)
        Me.R.Name = "R"
        Me.R.Size = New System.Drawing.Size(75, 31)
        Me.R.TabIndex = 5
        Me.R.Text = "Resta"
        Me.R.UseVisualStyleBackColor = True
        '
        'M
        '
        Me.M.Font = New System.Drawing.Font("Bauhaus 93", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.M.Location = New System.Drawing.Point(218, 122)
        Me.M.Name = "M"
        Me.M.Size = New System.Drawing.Size(123, 31)
        Me.M.TabIndex = 6
        Me.M.Text = "Multiplicación"
        Me.M.UseVisualStyleBackColor = True
        '
        'D
        '
        Me.D.Font = New System.Drawing.Font("Bauhaus 93", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.D.Location = New System.Drawing.Point(356, 122)
        Me.D.Name = "D"
        Me.D.Size = New System.Drawing.Size(88, 31)
        Me.D.TabIndex = 7
        Me.D.Text = "Divición"
        Me.D.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Pink
        Me.ClientSize = New System.Drawing.Size(482, 207)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.M)
        Me.Controls.Add(Me.R)
        Me.Controls.Add(Me.S)
        Me.Controls.Add(Me.n1)
        Me.Controls.Add(Me.n2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "UENTAS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents n2 As TextBox
    Friend WithEvents n1 As TextBox
    Friend WithEvents S As Button
    Friend WithEvents R As Button
    Friend WithEvents M As Button
    Friend WithEvents D As Button
End Class
