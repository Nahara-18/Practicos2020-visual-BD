﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.siete = New System.Windows.Forms.Button()
        Me.X = New System.Windows.Forms.Button()
        Me.Res = New System.Windows.Forms.Button()
        Me.Sum = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.Button()
        Me.punto = New System.Windows.Forms.Button()
        Me.cero = New System.Windows.Forms.Button()
        Me.igu = New System.Windows.Forms.Button()
        Me.tres = New System.Windows.Forms.Button()
        Me.dos = New System.Windows.Forms.Button()
        Me.uno = New System.Windows.Forms.Button()
        Me.seis = New System.Windows.Forms.Button()
        Me.cinco = New System.Windows.Forms.Button()
        Me.cuatro = New System.Windows.Forms.Button()
        Me.D = New System.Windows.Forms.Button()
        Me.nueve = New System.Windows.Forms.Button()
        Me.ocho = New System.Windows.Forms.Button()
        Me.numero = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'siete
        '
        Me.siete.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.siete.Location = New System.Drawing.Point(12, 53)
        Me.siete.Name = "siete"
        Me.siete.Size = New System.Drawing.Size(54, 47)
        Me.siete.TabIndex = 0
        Me.siete.Text = "7"
        Me.siete.UseVisualStyleBackColor = True
        '
        'X
        '
        Me.X.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.X.Location = New System.Drawing.Point(193, 106)
        Me.X.Name = "X"
        Me.X.Size = New System.Drawing.Size(54, 47)
        Me.X.TabIndex = 1
        Me.X.Text = "X"
        Me.X.UseVisualStyleBackColor = True
        '
        'Res
        '
        Me.Res.Font = New System.Drawing.Font("Rockwell", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Res.Location = New System.Drawing.Point(193, 159)
        Me.Res.Name = "Res"
        Me.Res.Size = New System.Drawing.Size(54, 47)
        Me.Res.TabIndex = 2
        Me.Res.Text = "-"
        Me.Res.UseVisualStyleBackColor = True
        '
        'Sum
        '
        Me.Sum.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sum.Location = New System.Drawing.Point(193, 212)
        Me.Sum.Name = "Sum"
        Me.Sum.Size = New System.Drawing.Size(54, 47)
        Me.Sum.TabIndex = 3
        Me.Sum.Text = "+"
        Me.Sum.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.Font = New System.Drawing.Font("Rockwell", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C.Location = New System.Drawing.Point(133, 212)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(54, 47)
        Me.C.TabIndex = 4
        Me.C.Text = "C"
        Me.C.UseVisualStyleBackColor = True
        '
        'punto
        '
        Me.punto.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.punto.Location = New System.Drawing.Point(72, 212)
        Me.punto.Name = "punto"
        Me.punto.Size = New System.Drawing.Size(54, 47)
        Me.punto.TabIndex = 5
        Me.punto.Text = "."
        Me.punto.UseVisualStyleBackColor = True
        '
        'cero
        '
        Me.cero.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cero.Location = New System.Drawing.Point(12, 212)
        Me.cero.Name = "cero"
        Me.cero.Size = New System.Drawing.Size(54, 47)
        Me.cero.TabIndex = 6
        Me.cero.Text = "0"
        Me.cero.UseVisualStyleBackColor = True
        '
        'igu
        '
        Me.igu.Font = New System.Drawing.Font("Forte", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.igu.Location = New System.Drawing.Point(12, 265)
        Me.igu.Name = "igu"
        Me.igu.Size = New System.Drawing.Size(235, 24)
        Me.igu.TabIndex = 7
        Me.igu.Text = "="
        Me.igu.UseVisualStyleBackColor = True
        '
        'tres
        '
        Me.tres.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tres.Location = New System.Drawing.Point(133, 159)
        Me.tres.Name = "tres"
        Me.tres.Size = New System.Drawing.Size(54, 47)
        Me.tres.TabIndex = 8
        Me.tres.Text = "3"
        Me.tres.UseVisualStyleBackColor = True
        '
        'dos
        '
        Me.dos.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dos.Location = New System.Drawing.Point(72, 159)
        Me.dos.Name = "dos"
        Me.dos.Size = New System.Drawing.Size(54, 47)
        Me.dos.TabIndex = 9
        Me.dos.Text = "2"
        Me.dos.UseVisualStyleBackColor = True
        '
        'uno
        '
        Me.uno.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.uno.Location = New System.Drawing.Point(12, 159)
        Me.uno.Name = "uno"
        Me.uno.Size = New System.Drawing.Size(54, 47)
        Me.uno.TabIndex = 10
        Me.uno.Text = "1"
        Me.uno.UseVisualStyleBackColor = True
        '
        'seis
        '
        Me.seis.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.seis.Location = New System.Drawing.Point(133, 106)
        Me.seis.Name = "seis"
        Me.seis.Size = New System.Drawing.Size(54, 47)
        Me.seis.TabIndex = 11
        Me.seis.Text = "6"
        Me.seis.UseVisualStyleBackColor = True
        '
        'cinco
        '
        Me.cinco.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cinco.Location = New System.Drawing.Point(72, 106)
        Me.cinco.Name = "cinco"
        Me.cinco.Size = New System.Drawing.Size(54, 47)
        Me.cinco.TabIndex = 12
        Me.cinco.Text = "5"
        Me.cinco.UseVisualStyleBackColor = True
        '
        'cuatro
        '
        Me.cuatro.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cuatro.Location = New System.Drawing.Point(12, 106)
        Me.cuatro.Name = "cuatro"
        Me.cuatro.Size = New System.Drawing.Size(54, 47)
        Me.cuatro.TabIndex = 13
        Me.cuatro.Text = "4"
        Me.cuatro.UseVisualStyleBackColor = True
        '
        'D
        '
        Me.D.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.D.Location = New System.Drawing.Point(193, 53)
        Me.D.Name = "D"
        Me.D.Size = New System.Drawing.Size(54, 47)
        Me.D.TabIndex = 14
        Me.D.Text = "/"
        Me.D.UseVisualStyleBackColor = True
        '
        'nueve
        '
        Me.nueve.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nueve.Location = New System.Drawing.Point(133, 53)
        Me.nueve.Name = "nueve"
        Me.nueve.Size = New System.Drawing.Size(54, 47)
        Me.nueve.TabIndex = 15
        Me.nueve.Text = "9"
        Me.nueve.UseVisualStyleBackColor = True
        '
        'ocho
        '
        Me.ocho.Font = New System.Drawing.Font("Forte", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ocho.Location = New System.Drawing.Point(72, 53)
        Me.ocho.Name = "ocho"
        Me.ocho.Size = New System.Drawing.Size(54, 47)
        Me.ocho.TabIndex = 16
        Me.ocho.Text = "8"
        Me.ocho.UseVisualStyleBackColor = True
        '
        'numero
        '
        Me.numero.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.numero.Location = New System.Drawing.Point(16, 12)
        Me.numero.Name = "numero"
        Me.numero.Size = New System.Drawing.Size(232, 26)
        Me.numero.TabIndex = 17
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumTurquoise
        Me.ClientSize = New System.Drawing.Size(260, 306)
        Me.Controls.Add(Me.numero)
        Me.Controls.Add(Me.ocho)
        Me.Controls.Add(Me.nueve)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.cuatro)
        Me.Controls.Add(Me.cinco)
        Me.Controls.Add(Me.seis)
        Me.Controls.Add(Me.uno)
        Me.Controls.Add(Me.dos)
        Me.Controls.Add(Me.tres)
        Me.Controls.Add(Me.igu)
        Me.Controls.Add(Me.cero)
        Me.Controls.Add(Me.punto)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.Sum)
        Me.Controls.Add(Me.Res)
        Me.Controls.Add(Me.X)
        Me.Controls.Add(Me.siete)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents siete As Button
    Friend WithEvents X As Button
    Friend WithEvents Res As Button
    Friend WithEvents Sum As Button
    Friend WithEvents C As Button
    Friend WithEvents punto As Button
    Friend WithEvents cero As Button
    Friend WithEvents igu As Button
    Friend WithEvents tres As Button
    Friend WithEvents dos As Button
    Friend WithEvents uno As Button
    Friend WithEvents seis As Button
    Friend WithEvents cinco As Button
    Friend WithEvents cuatro As Button
    Friend WithEvents D As Button
    Friend WithEvents nueve As Button
    Friend WithEvents ocho As Button
    Friend WithEvents numero As TextBox
End Class
