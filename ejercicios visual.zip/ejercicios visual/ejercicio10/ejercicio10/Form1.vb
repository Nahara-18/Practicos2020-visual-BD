﻿Public Class Form1

    Private Sub igu_Click(sender As Object, e As EventArgs) Handles igu.Click


        Dim suma, resta As Integer
        ' x sera la pocicion despues de un /,X,+,- | a determina pocicion de multi o divi
        Dim cant, pos, x, a As Integer
        Dim num1, num2, cuenta As Double
        'y indica si la cuentas es de x o /
        Dim caract, y As String
        cant = Len(numero.Text)
        pos = 1
        x = 1
        a = 0
        ' esto realizara las muliplicaciones y diviciones
        While (pos <= cant)
            caract = Mid(numero.Text, pos, 1)

            If (caract = "+" Or caract = "-") Then
                x = pos + 1
                a += 1
            ElseIf (caract = "x" Or caract = "/") Then
                y = Mid(numero.Text, pos, 1)
                num1 = Val(Mid(numero.Text, x, pos - 1))
                x = pos + 1

                'h indica que ya se guardo el num 2 
                'c indicaria la cantidaad del num 2
                Dim h As Integer = 0
                Dim car As String
                Dim pos2 As Integer
                pos2 = pos
                Dim c As Integer = 1
                While (h = 0)
                    car = Mid(numero.Text, pos2 + 1, 1)
                    If (car = "x" Or car = "/" Or car = "+" Or car = "-") Then
                        num2 = Val(Mid(numero.Text, x, c - 1))
                        h = 1
                    ElseIf (pos2 = cant) Then
                        num2 = Val(Mid(numero.Text, x, c))
                        h = 1
                    End If
                    pos2 += 1
                    c += 1
                End While
                'definira y realizara la cuenta
                If y = "x" Then
                    cuenta = Val(num1) * Val(num2)
                Else
                    cuenta = Val(num1) / Val(num2)
                End If

                If (a = 0) Then
                    numero.Text = cuenta & Mid(numero.Text, pos2)
                ElseIf (a > 0) Then
                    numero.Text = Mid(numero.Text, a, pos - 1) + cuenta + Mid(numero.Text, pos2)
                End If 
                pos = 1
                x = 1
            End If
            pos += 1
        End While

                          ' Este realizara las sumas y las restas
        pos = 1
        x = 1
        a = 0
        While (pos <= cant)
            caract = Mid(numero.Text, pos, 1)

            If (caract = "+" Or caract = "-") Then
                y = Mid(numero.Text, pos, 1)
                num1 = Val(Mid(numero.Text, x, pos - 1))
                x = pos + 1

                'h indica que ya se guardo el num 2 
                'c indicaria la cantidaad del num 2
                Dim h As Integer = 0
                Dim car As String
                Dim pos2 As Integer
                pos2 = pos
                Dim c As Integer = 1
                While (h = 0)
                    car = Mid(numero.Text, pos2 + 1, 1)
                    If (car = "x" Or car = "/" Or car = "+" Or car = "-") Then
                        num2 = Val(Mid(numero.Text, x, c - 1))
                        h = 1
                    ElseIf (pos2 = cant) Then
                        num2 = Val(Mid(numero.Text, x, c))
                        h = 1
                    End If
                    pos2 += 1
                    c += 1
                End While
                'definira y realizara la cuenta
                If y = "+" Then
                    cuenta = Val(num1) + Val(num2)
                Else
                    cuenta = Val(num1) - Val(num2)
                End If

                If (a = 0) Then
                    numero.Text = cuenta & Mid(numero.Text, pos2)
                ElseIf (a > 0) Then
                    numero.Text = Mid(numero.Text, a, pos - 1) + cuenta + Mid(numero.Text, pos2)
                End If

                pos = 1
                x = 1

            End If
            pos += 1
        End While

    End Sub


    Private Sub D_Click(sender As Object, e As EventArgs) Handles D.Click
        Dim cant As Integer
        Dim caract As String
        cant = Len(numero.Text) Or 1
        caract = Mid(numero.Text, cant, 1)

        If (numero.Text = Nothing) Then

        ElseIf (caract = "x" Or caract = "+" Or caract = "-" Or caract = "." Or caract = "/") Then
            numero.Text = Mid(numero.Text, 1, (cant - 1)) + "/"
        Else
            numero.Text = (numero.Text) + "/"
        End If

    End Sub
    Private Sub X_Click(sender As Object, e As EventArgs) Handles X.Click
        Dim cant As Integer
        Dim caract As String
        cant = Len(numero.Text) Or 1
        caract = Mid(numero.Text, cant, 1)

        If (numero.Text = Nothing) Then

        ElseIf (caract = "/" Or caract = "+" Or caract = "-" Or caract = "." Or caract = "x") Then
            numero.Text = Mid(numero.Text, 1, (cant - 1)) + "x"
        Else
            numero.Text = (numero.Text) + "x"
        End If
    End Sub
    Private Sub Res_Click(sender As Object, e As EventArgs) Handles Res.Click
        Dim cant As Integer
        Dim caract As String
        cant = Len(numero.Text) Or 1
        caract = Mid(numero.Text, cant, 1)

        If (caract = "/" Or caract = "x" Or caract = "-" Or caract = "." Or caract = "+") Then
            numero.Text = Mid(numero.Text, 1, (cant - 1)) + "-"
        Else
            numero.Text = (numero.Text) + "-"
        End If
    End Sub

    Private Sub Sum_Click(sender As Object, e As EventArgs) Handles Sum.Click
        Dim cant As Integer
        Dim caract As String
        cant = Len(numero.Text) Or 1
        caract = Mid(numero.Text, cant, 1)

        If (caract = "/" Or caract = "x" Or caract = "+" Or caract = "." Or caract = "-") Then
            numero.Text = Mid(numero.Text, 1, (cant - 1)) + "+"
        Else
            numero.Text = (numero.Text) + "+"
        End If
    End Sub
    Private Sub punto_Click(sender As Object, e As EventArgs) Handles punto.Click
        Dim cant As Integer
        Dim caract As String
        cant = Len(numero.Text)
        caract = Mid(numero.Text, cant, 1)

        If (caract = "x" Or caract = "+" Or caract = "-" Or caract = "/" Or caract = ".") Then
            numero.Text = Mid(numero.Text, 1, (cant - 1)) + "."
        Else
            numero.Text = (numero.Text) + "."
        End If
    End Sub

    Private Sub numero_KeyPress(sender As Object, e As KeyPressEventArgs) Handles numero.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf e.KeyChar = "." Then
            e.Handled = False
        ElseIf (numero.Text = "" And e.KeyChar = "/") Then
            e.Handled = True
        ElseIf e.KeyChar = "/" Then
            e.Handled = False
        ElseIf e.KeyChar = "+" Then
            e.Handled = False
        ElseIf e.KeyChar = "-" Then
            e.Handled = False
        ElseIf (numero.Text = "" And e.KeyChar = "x") Then
            e.Handled = True
        ElseIf e.KeyChar = "x" Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub cero_Click(sender As Object, e As EventArgs) Handles cero.Click
        numero.Text = (numero.Text) + "0"
    End Sub
    Private Sub uno_Click(sender As Object, e As EventArgs) Handles uno.Click
        numero.Text = (numero.Text) + "1"
    End Sub
    Private Sub dos_Click(sender As Object, e As EventArgs) Handles dos.Click
        numero.Text = (numero.Text) + "2"
    End Sub
    Private Sub tres_Click(sender As Object, e As EventArgs) Handles tres.Click
        numero.Text = (numero.Text) + "3"
    End Sub
    Private Sub cuatro_Click(sender As Object, e As EventArgs) Handles cuatro.Click
        numero.Text = (numero.Text) + "4"
    End Sub
    Private Sub cinco_Click(sender As Object, e As EventArgs) Handles cinco.Click
        numero.Text = (numero.Text) + "5"
    End Sub
    Private Sub seis_Click(sender As Object, e As EventArgs) Handles seis.Click
        numero.Text = (numero.Text) + "6"
    End Sub
    Private Sub siete_Click(sender As Object, e As EventArgs) Handles siete.Click
        numero.Text = (numero.Text) + "7"
    End Sub
    Private Sub ocho_Click(sender As Object, e As EventArgs) Handles ocho.Click
        numero.Text = (numero.Text) + "8"
    End Sub
    Private Sub nueve_Click(sender As Object, e As EventArgs) Handles nueve.Click
        numero.Text = (numero.Text) + "9"
    End Sub

    Private Sub C_Click(sender As Object, e As EventArgs) Handles C.Click
        numero.Text = ""
    End Sub

End Class
