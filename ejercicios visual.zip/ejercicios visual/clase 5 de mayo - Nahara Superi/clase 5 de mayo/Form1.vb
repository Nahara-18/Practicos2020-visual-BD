﻿Public Class Form1
    Dim b, c, d, f, g, h As Integer
    Dim a As Integer = 0

    Private Sub TextBox1_Leave(sender As Object, e As EventArgs) Handles cedu.Leave
        If (Modulo.vacio(cedu.Text) = True) Then
            Label1.Text = "CI* -Este campo no puede quedar vacio"
            Label1.ForeColor = ForeColor.Red
            a = 1
        ElseIf (Modulo.cedula(cedu.Text) = False) Then
            Label1.Text = "CI* -cedula no valida"
            Label1.ForeColor = ForeColor.Red
            a = 1
        Else
            Label1.Text = "CI"
            Label1.ForeColor = ForeColor.Black
            a = 0
        End If
    End Sub

    Private Sub TextBox8_Leave(sender As Object, e As EventArgs) Handles con1.Leave
        If (Modulo.vacio(con1.Text) = True) Then
            Label2.Text = "contraseña* -contraseña no puede estar vacia"
            Label2.ForeColor = ForeColor.Red
            b = 1
        Else
            Label2.Text = "contraseña"
            b = 0
            Label2.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub cedu2_Leave(sender As Object, e As EventArgs) Handles con2.Leave
        If (Modulo.contraseña(con1.Text, con2.Text) = False) Then
            Label22.Text = "Repetir contraseña* - la contraseña no es igual"
            Label22.ForeColor = ForeColor.Red
            c = 1
        Else
            c = 0
            Label22.Text = "Repetir contraseña"
            Label22.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub TextBox7_Leave(sender As Object, e As EventArgs) Handles nom1.Leave
        If (Modulo.vacio(nom1.Text) = True) Then
            Label3.Text = "Primer nombre* - Este campo es obligatorio"
            Label3.ForeColor = ForeColor.Red
            d = 1
        Else
            Label3.Text = "Primer Nombre"
            Label3.ForeColor = ForeColor.Black
            d = 0
        End If
    End Sub

    Private Sub ap1_Leave(sender As Object, e As EventArgs) Handles ap1.Leave
        If (Modulo.vacio(ap1.Text) = True) Then
            Label4.Text = "Primer apellido* - Este campo es obligatorio"
            Label4.ForeColor = ForeColor.Red
            f = 1
        Else
            Label4.Text = "Primer apellido"
            Label4.ForeColor = ForeColor.Black
            f = 0
        End If
    End Sub

    Private Sub ap2_Leave(sender As Object, e As EventArgs) Handles ap2.Leave
        If (Modulo.vacio(ap2.Text) = True) Then
            Label44.Text = "Segundo apellido* - Este campo es obligatorio"
            Label44.ForeColor = ForeColor.Red
            g = 1
        Else
            Label44.Text = "Segundo apellido"
            Label44.ForeColor = ForeColor.Black
            g = 0
        End If
    End Sub

    Private Sub email_Leave(sender As Object, e As EventArgs) Handles email.Leave
        If (Modulo.vacio(email.Text) = True) Then
            Label5.Text = "Email* -Este campo es obligatorio"
            Label5.ForeColor = ForeColor.Red
            h = 1
        ElseIf (Modulo.email(email.Text) = False) Then
            Label5.Text = "Email - tiene que contener un @ y un punto"
            Label5.ForeColor = ForeColor.Red
            h = 1
        Else
            h = 0
            Label5.Text = "Email"
            Label5.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (a = 0 And b = 0 And c = 0 And d = 0 And f = 0 And g = 0 And h = 0) Then
            login.Visible = True
        Else
            MsgBox("Ingrese correctamente los datos")
        End If

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cedu.KeyPress
        'Esto indica que solo se puede ingresar numeros y borrar en el textbox
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub con1_TextChanged(sender As Object, e As EventArgs) Handles con1.TextChanged
        con1.UseSystemPasswordChar = True
    End Sub

    Private Sub con2_TextChanged(sender As Object, e As EventArgs) Handles con2.TextChanged
        con2.UseSystemPasswordChar = True
    End Sub
End Class
