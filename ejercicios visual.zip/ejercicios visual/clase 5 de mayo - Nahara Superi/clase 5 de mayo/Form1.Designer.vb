﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cedu = New System.Windows.Forms.TextBox()
        Me.ap2 = New System.Windows.Forms.TextBox()
        Me.email = New System.Windows.Forms.TextBox()
        Me.nom2 = New System.Windows.Forms.TextBox()
        Me.con2 = New System.Windows.Forms.TextBox()
        Me.ap1 = New System.Windows.Forms.TextBox()
        Me.nom1 = New System.Windows.Forms.TextBox()
        Me.con1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cedu
        '
        Me.cedu.Location = New System.Drawing.Point(43, 56)
        Me.cedu.Name = "cedu"
        Me.cedu.Size = New System.Drawing.Size(167, 20)
        Me.cedu.TabIndex = 0
        '
        'ap2
        '
        Me.ap2.Location = New System.Drawing.Point(266, 185)
        Me.ap2.Name = "ap2"
        Me.ap2.Size = New System.Drawing.Size(167, 20)
        Me.ap2.TabIndex = 1
        '
        'email
        '
        Me.email.Location = New System.Drawing.Point(43, 244)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(407, 20)
        Me.email.TabIndex = 2
        '
        'nom2
        '
        Me.nom2.Location = New System.Drawing.Point(266, 142)
        Me.nom2.Name = "nom2"
        Me.nom2.Size = New System.Drawing.Size(167, 20)
        Me.nom2.TabIndex = 3
        '
        'con2
        '
        Me.con2.Location = New System.Drawing.Point(266, 99)
        Me.con2.Name = "con2"
        Me.con2.Size = New System.Drawing.Size(167, 20)
        Me.con2.TabIndex = 4
        '
        'ap1
        '
        Me.ap1.Location = New System.Drawing.Point(43, 185)
        Me.ap1.Name = "ap1"
        Me.ap1.Size = New System.Drawing.Size(167, 20)
        Me.ap1.TabIndex = 5
        '
        'nom1
        '
        Me.nom1.Location = New System.Drawing.Point(43, 142)
        Me.nom1.Name = "nom1"
        Me.nom1.Size = New System.Drawing.Size(167, 20)
        Me.nom1.TabIndex = 6
        '
        'con1
        '
        Me.con1.Location = New System.Drawing.Point(43, 99)
        Me.con1.Name = "con1"
        Me.con1.Size = New System.Drawing.Size(167, 20)
        Me.con1.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(331, 297)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(119, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Registrarme"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "CI*"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(280, 83)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(101, 13)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Repetir contraseña*"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(51, 169)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Primer apellido*"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(51, 228)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Email*"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(280, 169)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(93, 13)
        Me.Label44.TabIndex = 13
        Me.Label44.Text = "Segundo apellido*"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(280, 122)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(88, 13)
        Me.Label33.TabIndex = 14
        Me.Label33.Text = "Segundo nombre"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(51, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Primer nombre*"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(51, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Contraseña*"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(519, 350)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.con1)
        Me.Controls.Add(Me.nom1)
        Me.Controls.Add(Me.ap1)
        Me.Controls.Add(Me.con2)
        Me.Controls.Add(Me.nom2)
        Me.Controls.Add(Me.email)
        Me.Controls.Add(Me.ap2)
        Me.Controls.Add(Me.cedu)
        Me.Name = "Form1"
        Me.Text = "Registro"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cedu As TextBox
    Friend WithEvents ap2 As TextBox
    Friend WithEvents email As TextBox
    Friend WithEvents nom2 As TextBox
    Friend WithEvents con2 As TextBox
    Friend WithEvents ap1 As TextBox
    Friend WithEvents nom1 As TextBox
    Friend WithEvents con1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
End Class
