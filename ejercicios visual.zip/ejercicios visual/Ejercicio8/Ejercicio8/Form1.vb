﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C.Text)
        pos = 1
        arr = 0
        multi = 0
        suma = 0

        If (cantidad = 8) Then

            While (pos < 8)
                car = Mid(C.Text, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While
            resto = 10 - Mid(suma, 3, 1)
            If (resto = Mid(C.Text, 8, 1)) Then
                v.Text = "La cedula es valida"
            Else
                v.Text = "Cedula no valida"
            End If

        Else
            v.Text = "Cantidad de caracteres incorrecta para una cedula"
        End If
    End Sub

    Private Sub C_KeyPress(sender As Object, e As KeyPressEventArgs) Handles C.KeyPress
        'Esto indica que solo se puede ingresar numeros y borrar en el textbox
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class
